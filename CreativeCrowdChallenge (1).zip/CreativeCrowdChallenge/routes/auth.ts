// routes/auth.ts
import express from "express";
import passport from "../auth/passport"; // Adjust the path if needed
import { insertUserSchema } from "@shared/schema"; // Adjust the path if needed
import { storage } from "../storage"; // Adjust the path if needed
import { z } from "zod";

const router = express.Router();

// Register a new user
router.post("/register", async (req, res) => {
  try {
    const userData = insertUserSchema.parse(req.body);

    // Check if the username already exists
    const existingUsername = await storage.getUserByUsername(userData.username);
    if (existingUsername) {
      return res.status(400).json({ message: "Username already taken" });
    }

    // Check if the email already exists
    const existingEmail = await storage.getUserByEmail(userData.email);
    if (existingEmail) {
      return res.status(400).json({ message: "Email already registered" });
    }

    // Create the user
    const user = await storage.createUser(userData);

    // Remove the password from the response
    const { password, ...userWithoutPassword } = user;

    return res.status(201).json(userWithoutPassword);
  } catch (error) {
    return res.status(400).json({ message: "Validation error", errors: error });
  }
});

// Log in a user
router.post("/login", (req, res, next) => {
  passport.authenticate("local", (err, user, info) => {
    if (err) {
      return next(err);
    }
    if (!user) {
      return res.status(401).json({ message: info.message });
    }

    // Log in the user
    req.logIn(user, (err) => {
      if (err) {
        return next(err);
      }

      // Remove the password from the response
      const { password, ...userWithoutPassword } = user;

      return res.status(200).json(userWithoutPassword);
    });
  })(req, res, next);
});

// Log out a user
router.post("/logout", (req, res) => {
  req.logout((err) => {
    if (err) {
      return res.status(500).json({ message: "Failed to log out" });
    }
    return res.status(200).json({ message: "Logged out successfully" });
  });
});

export default router;
