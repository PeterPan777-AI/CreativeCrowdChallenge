import { 
  users, type User, type InsertUser,
  categories, type Category, type InsertCategory,
  competitions, type Competition, type InsertCompetition,
  submissions, type Submission, type InsertSubmission,
  ratings, type Rating, type InsertRating,
  categorySuggestions, type CategorySuggestion, type InsertCategorySuggestion
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryByName(name: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Category suggestion operations
  getCategorySuggestions(): Promise<CategorySuggestion[]>;
  getCategorySuggestion(id: number): Promise<CategorySuggestion | undefined>;
  createCategorySuggestion(suggestion: InsertCategorySuggestion): Promise<CategorySuggestion>;
  updateCategorySuggestionStatus(id: number, status: string): Promise<CategorySuggestion | undefined>;
  
  // Competition operations
  getCompetitions(): Promise<Competition[]>;
  getCompetition(id: number): Promise<Competition | undefined>;
  getActiveCompetitions(): Promise<Competition[]>;
  getCompetitionsByCategory(categoryId: number): Promise<Competition[]>;
  createCompetition(competition: InsertCompetition): Promise<Competition>;
  
  // Submission operations
  getSubmissions(): Promise<Submission[]>;
  getSubmission(id: number): Promise<Submission | undefined>;
  getSubmissionsByCompetition(competitionId: number): Promise<Submission[]>;
  getSubmissionsByUser(userId: number): Promise<Submission[]>;
  getPopularSubmissions(limit?: number): Promise<Submission[]>;
  createSubmission(submission: InsertSubmission): Promise<Submission>;
  
  // Rating operations
  getRating(id: number): Promise<Rating | undefined>;
  getRatingByUserAndSubmission(userId: number, submissionId: number): Promise<Rating | undefined>;
  createRating(rating: InsertRating): Promise<Rating>;
  updateRating(id: number, value: number): Promise<Rating | undefined>;
  
  // Other operations
  getLeaderboard(competitionId?: number, limit?: number): Promise<Submission[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private competitions: Map<number, Competition>;
  private submissions: Map<number, Submission>;
  private ratings: Map<number, Rating>;
  private categorySuggestions: Map<number, CategorySuggestion>;
  
  private userId: number;
  private categoryId: number;
  private competitionId: number;
  private submissionId: number;
  private ratingId: number;
  private categorySuggestionId: number;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.competitions = new Map();
    this.submissions = new Map();
    this.ratings = new Map();
    this.categorySuggestions = new Map();
    
    this.userId = 1;
    this.categoryId = 1;
    this.competitionId = 1;
    this.submissionId = 1;
    this.ratingId = 1;
    this.categorySuggestionId = 1;
    
    // Initialize with sample data
    this.initSampleData();
  }

  private initSampleData() {
    // Categories
    const photoCategory: InsertCategory = {
      name: "Photography",
      description: "Photography competitions",
      icon: "camera",
      color: "blue",
    };
    
    const videoCategory: InsertCategory = {
      name: "Video",
      description: "Video competitions",
      icon: "video",
      color: "green",
    };
    
    const musicCategory: InsertCategory = {
      name: "Music",
      description: "Music competitions",
      icon: "headphones",
      color: "purple",
    };
    
    const lyricsCategory: InsertCategory = {
      name: "Lyrics",
      description: "Lyrics competitions",
      icon: "mic",
      color: "pink",
    };
    
    // Create categories
    this.createCategory(photoCategory);
    this.createCategory(videoCategory);
    this.createCategory(musicCategory);
    this.createCategory(lyricsCategory);
    
    // Create sample competitions
    const now = new Date();
    const oneWeekFromNow = new Date(now);
    oneWeekFromNow.setDate(oneWeekFromNow.getDate() + 7);
    
    const twoWeeksFromNow = new Date(now);
    twoWeeksFromNow.setDate(twoWeeksFromNow.getDate() + 14);
    
    const oneMonthFromNow = new Date(now);
    oneMonthFromNow.setDate(oneMonthFromNow.getDate() + 30);
    
    const photoCompetition: InsertCompetition = {
      title: "Summer Vibes Photography",
      description: "Capture the essence of summer in a single stunning photo.",
      categoryId: 1,
      prizeAmount: 500,
      sponsoredBy: "PhotoGear Inc.",
      startDate: now,
      endDate: oneWeekFromNow,
      isActive: true,
    };
    
    const musicCompetition: InsertCompetition = {
      title: "Indie Track Challenge",
      description: "Create an original indie track in any style that moves you.",
      categoryId: 3,
      prizeAmount: 750,
      sponsoredBy: "MusicWorld",
      startDate: now,
      endDate: twoWeeksFromNow,
      isActive: true,
    };
    
    const videoCompetition: InsertCompetition = {
      title: "60-Second Story",
      description: "Tell a compelling story in just 60 seconds of video.",
      categoryId: 2,
      prizeAmount: 1000,
      sponsoredBy: "VideoNow",
      startDate: now,
      endDate: oneMonthFromNow,
      isActive: true,
    };
    
    this.createCompetition(photoCompetition);
    this.createCompetition(musicCompetition);
    this.createCompetition(videoCompetition);
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return [...this.users.values()].find(user => user.username === username);
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return [...this.users.values()].find(user => user.email === email);
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const newUser: User = { ...user, id, createdAt: now };
    this.users.set(id, newUser);
    return newUser;
  }
  
  // Category operations
  async getCategories(): Promise<Category[]> {
    return [...this.categories.values()];
  }
  
  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async getCategoryByName(name: string): Promise<Category | undefined> {
    return [...this.categories.values()].find(category => category.name === name);
  }
  
  async createCategory(category: InsertCategory): Promise<Category> {
    const id = this.categoryId++;
    const newCategory: Category = { ...category, id };
    this.categories.set(id, newCategory);
    return newCategory;
  }
  
  // Category suggestion operations
  async getCategorySuggestions(): Promise<CategorySuggestion[]> {
    return [...this.categorySuggestions.values()];
  }
  
  async getCategorySuggestion(id: number): Promise<CategorySuggestion | undefined> {
    return this.categorySuggestions.get(id);
  }
  
  async createCategorySuggestion(suggestion: InsertCategorySuggestion): Promise<CategorySuggestion> {
    const id = this.categorySuggestionId++;
    const now = new Date();
    const newSuggestion: CategorySuggestion = { 
      ...suggestion, 
      id, 
      status: 'pending', 
      createdAt: now 
    };
    this.categorySuggestions.set(id, newSuggestion);
    return newSuggestion;
  }
  
  async updateCategorySuggestionStatus(id: number, status: string): Promise<CategorySuggestion | undefined> {
    const suggestion = await this.getCategorySuggestion(id);
    if (!suggestion) return undefined;
    
    const updatedSuggestion: CategorySuggestion = { ...suggestion, status };
    this.categorySuggestions.set(id, updatedSuggestion);
    return updatedSuggestion;
  }
  
  // Competition operations
  async getCompetitions(): Promise<Competition[]> {
    return [...this.competitions.values()];
  }
  
  async getCompetition(id: number): Promise<Competition | undefined> {
    return this.competitions.get(id);
  }
  
  async getActiveCompetitions(): Promise<Competition[]> {
    const now = new Date();
    return [...this.competitions.values()].filter(
      competition => competition.isActive && competition.endDate > now
    );
  }
  
  async getCompetitionsByCategory(categoryId: number): Promise<Competition[]> {
    return [...this.competitions.values()].filter(
      competition => competition.categoryId === categoryId
    );
  }
  
  async createCompetition(competition: InsertCompetition): Promise<Competition> {
    const id = this.competitionId++;
    const now = new Date();
    const newCompetition: Competition = { ...competition, id, createdAt: now };
    this.competitions.set(id, newCompetition);
    return newCompetition;
  }
  
  // Submission operations
  async getSubmissions(): Promise<Submission[]> {
    return [...this.submissions.values()];
  }
  
  async getSubmission(id: number): Promise<Submission | undefined> {
    return this.submissions.get(id);
  }
  
  async getSubmissionsByCompetition(competitionId: number): Promise<Submission[]> {
    return [...this.submissions.values()].filter(
      submission => submission.competitionId === competitionId
    );
  }
  
  async getSubmissionsByUser(userId: number): Promise<Submission[]> {
    return [...this.submissions.values()].filter(
      submission => submission.userId === userId
    );
  }
  
  async getPopularSubmissions(limit: number = 10): Promise<Submission[]> {
    return [...this.submissions.values()]
      .sort((a, b) => b.averageRating - a.averageRating)
      .slice(0, limit);
  }
  
  async createSubmission(submission: InsertSubmission): Promise<Submission> {
    const id = this.submissionId++;
    const now = new Date();
    const newSubmission: Submission = { 
      ...submission, 
      id, 
      averageRating: 0, 
      totalRatings: 0,
      createdAt: now 
    };
    this.submissions.set(id, newSubmission);
    return newSubmission;
  }
  
  // Rating operations
  async getRating(id: number): Promise<Rating | undefined> {
    return this.ratings.get(id);
  }
  
  async getRatingByUserAndSubmission(userId: number, submissionId: number): Promise<Rating | undefined> {
    return [...this.ratings.values()].find(
      rating => rating.userId === userId && rating.submissionId === submissionId
    );
  }
  
  async createRating(rating: InsertRating): Promise<Rating> {
    const id = this.ratingId++;
    const now = new Date();
    const newRating: Rating = { ...rating, id, createdAt: now };
    this.ratings.set(id, newRating);
    
    // Update submission's average rating
    const submission = await this.getSubmission(rating.submissionId);
    if (submission) {
      const submissionRatings = [...this.ratings.values()].filter(
        r => r.submissionId === rating.submissionId
      );
      
      const totalValue = submissionRatings.reduce((sum, r) => sum + r.value, 0);
      const count = submissionRatings.length;
      
      const updatedSubmission: Submission = {
        ...submission,
        averageRating: totalValue / count,
        totalRatings: count
      };
      
      this.submissions.set(submission.id, updatedSubmission);
    }
    
    return newRating;
  }
  
  async updateRating(id: number, value: number): Promise<Rating | undefined> {
    const rating = await this.getRating(id);
    if (!rating) return undefined;
    
    const updatedRating: Rating = { ...rating, value };
    this.ratings.set(id, updatedRating);
    
    // Update submission's average rating
    const submission = await this.getSubmission(rating.submissionId);
    if (submission) {
      const submissionRatings = [...this.ratings.values()].filter(
        r => r.submissionId === rating.submissionId
      );
      
      const totalValue = submissionRatings.reduce((sum, r) => sum + r.value, 0);
      const count = submissionRatings.length;
      
      const updatedSubmission: Submission = {
        ...submission,
        averageRating: totalValue / count,
        totalRatings: count
      };
      
      this.submissions.set(submission.id, updatedSubmission);
    }
    
    return updatedRating;
  }
  
  // Other operations
  async getLeaderboard(competitionId?: number, limit: number = 10): Promise<Submission[]> {
    let filteredSubmissions = [...this.submissions.values()];
    
    if (competitionId) {
      filteredSubmissions = filteredSubmissions.filter(
        submission => submission.competitionId === competitionId
      );
    }
    
    return filteredSubmissions
      .sort((a, b) => b.averageRating - a.averageRating)
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
