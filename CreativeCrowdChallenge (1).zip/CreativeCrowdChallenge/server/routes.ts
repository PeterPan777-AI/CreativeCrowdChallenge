import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertCategorySchema, 
  insertCompetitionSchema, 
  insertSubmissionSchema, 
  insertRatingSchema,
  insertCategorySuggestionSchema
} from "@shared/schema";
import { z } from "zod";
import { validateRequest } from "zod-express-middleware";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Helper function to handle zod validation errors
  const handleZodError = (error: unknown, res: Response) => {
    if (error instanceof ZodError) {
      return res.status(400).json({ 
        message: "Validation error", 
        errors: error.errors 
      });
    }
    
    console.error("Unexpected error:", error);
    return res.status(500).json({ 
      message: "An unexpected error occurred" 
    });
  };

  // USER ROUTES
  app.post('/api/auth/register', async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(userData.username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already taken" });
      }
      
      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already registered" });
      }
      
      const user = await storage.createUser(userData);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      return res.status(201).json(userWithoutPassword);
    } catch (error) {
      return handleZodError(error, res);
    }
  });
  
  app.post('/api/auth/login', async (req: Request, res: Response) => {
    try {
      const { username, password } = z.object({
        username: z.string(),
        password: z.string()
      }).parse(req.body);
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      return handleZodError(error, res);
    }
  });
  
  app.get('/api/users/:id', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      return handleZodError(error, res);
    }
  });
  
  // CATEGORY ROUTES
  app.get('/api/categories', async (_req: Request, res: Response) => {
    try {
      const categories = await storage.getCategories();
      return res.status(200).json(categories);
    } catch (error) {
      return handleZodError(error, res);
    }
  });
  
  app.get('/api/categories/:id', async (req: Request, res: Response) => {
    try {
      const categoryId = parseInt(req.params.id);
      const category = await storage.getCategory(categoryId);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      return res.status(200).json(category);
    } catch (error) {
      return handleZodError(error, res);
    }
  });
  
  // COMPETITION ROUTES
  app.get('/api/competitions', async (req: Request, res: Response) => {
    try {
      const categoryId = req.query.categoryId ? parseInt(req.query.categoryId as string) : undefined;
      const activeOnly = req.query.active === 'true';
      
      let competitions;
      
      if (categoryId) {
        competitions = await storage.getCompetitionsByCategory(categoryId);
      } else if (activeOnly) {
        competitions = await storage.getActiveCompetitions();
      } else {
        competitions = await storage.getCompetitions();
      }
      
      return res.status(200).json(competitions);
    } catch (error) {
      return handleZodError(error, res);
    }
  });
  
  app.get('/api/competitions/:id', async (req: Request, res: Response) => {
    try {
      const competitionId = parseInt(req.params.id);
      const competition = await storage.getCompetition(competitionId);
      
      if (!competition) {
        return res.status(404).json({ message: "Competition not found" });
      }
      
      return res.status(200).json(competition);
    } catch (error) {
      return handleZodError(error, res);
    }
  });
  
  app.post('/api/competitions', async (req: Request, res: Response) => {
    try {
      const competitionData = insertCompetitionSchema.parse(req.body);
      const competition = await storage.createCompetition(competitionData);
      return res.status(201).json(competition);
    } catch (error) {
      return handleZodError(error, res);
    }
  });
  
  // SUBMISSION ROUTES
  app.get('/api/submissions', async (req: Request, res: Response) => {
    try {
      const competitionId = req.query.competitionId ? parseInt(req.query.competitionId as string) : undefined;
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const popular = req.query.popular === 'true';
      
      let submissions;
      
      if (competitionId) {
        submissions = await storage.getSubmissionsByCompetition(competitionId);
      } else if (userId) {
        submissions = await storage.getSubmissionsByUser(userId);
      } else if (popular) {
        const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
        submissions = await storage.getPopularSubmissions(limit);
      } else {
        submissions = await storage.getSubmissions();
      }
      
      return res.status(200).json(submissions);
    } catch (error) {
      return handleZodError(error, res);
    }
  });
  
  app.get('/api/submissions/:id', async (req: Request, res: Response) => {
    try {
      const submissionId = parseInt(req.params.id);
      const submission = await storage.getSubmission(submissionId);
      
      if (!submission) {
        return res.status(404).json({ message: "Submission not found" });
      }
      
      return res.status(200).json(submission);
    } catch (error) {
      return handleZodError(error, res);
    }
  });
  
  app.post('/api/submissions', async (req: Request, res: Response) => {
    try {
      const submissionData = insertSubmissionSchema.parse(req.body);
      const submission = await storage.createSubmission(submissionData);
      return res.status(201).json(submission);
    } catch (error) {
      return handleZodError(error, res);
    }
  });
  
  // RATING ROUTES
  app.post('/api/ratings', async (req: Request, res: Response) => {
    try {
      const ratingData = insertRatingSchema.parse(req.body);
      
      // Check if user already rated this submission
      const existingRating = await storage.getRatingByUserAndSubmission(
        ratingData.userId, 
        ratingData.submissionId
      );
      
      if (existingRating) {
        // Update existing rating
        const updatedRating = await storage.updateRating(existingRating.id, ratingData.value);
        return res.status(200).json(updatedRating);
      } else {
        // Create new rating
        const rating = await storage.createRating(ratingData);
        return res.status(201).json(rating);
      }
    } catch (error) {
      return handleZodError(error, res);
    }
  });
  
  // CATEGORY SUGGESTIONS ROUTES
  app.post('/api/category-suggestions', async (req: Request, res: Response) => {
    try {
      const suggestionData = insertCategorySuggestionSchema.parse(req.body);
      const suggestion = await storage.createCategorySuggestion(suggestionData);
      return res.status(201).json(suggestion);
    } catch (error) {
      return handleZodError(error, res);
    }
  });
  
  app.get('/api/category-suggestions', async (_req: Request, res: Response) => {
    try {
      const suggestions = await storage.getCategorySuggestions();
      return res.status(200).json(suggestions);
    } catch (error) {
      return handleZodError(error, res);
    }
  });
  
  app.patch('/api/category-suggestions/:id/status', async (req: Request, res: Response) => {
    try {
      const suggestionId = parseInt(req.params.id);
      const { status } = z.object({
        status: z.enum(['pending', 'approved', 'rejected'])
      }).parse(req.body);
      
      const updatedSuggestion = await storage.updateCategorySuggestionStatus(suggestionId, status);
      
      if (!updatedSuggestion) {
        return res.status(404).json({ message: "Category suggestion not found" });
      }
      
      return res.status(200).json(updatedSuggestion);
    } catch (error) {
      return handleZodError(error, res);
    }
  });

  // LEADERBOARD ROUTE
  app.get('/api/leaderboard', async (req: Request, res: Response) => {
    try {
      const competitionId = req.query.competitionId ? parseInt(req.query.competitionId as string) : undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      
      const leaderboard = await storage.getLeaderboard(competitionId, limit);
      
      // Get user info for each submission
      const leaderboardWithUsers = await Promise.all(
        leaderboard.map(async (submission) => {
          const user = await storage.getUser(submission.userId);
          const { password, ...userWithoutPassword } = user || { password: '' };
          
          return {
            ...submission,
            user: userWithoutPassword
          };
        })
      );
      
      return res.status(200).json(leaderboardWithUsers);
    } catch (error) {
      return handleZodError(error, res);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
