export interface User {
  id: number;
  username: string;
  email: string;
  displayName: string;
  profilePicture?: string;
  bio?: string;
  createdAt: Date;
}

export interface Category {
  id: number;
  name: string;
  description?: string;
  icon: string;
  color: string;
}

export interface Competition {
  id: number;
  title: string;
  description: string;
  categoryId: number;
  prizeAmount?: number;
  sponsoredBy?: string;
  startDate: Date;
  endDate: Date;
  isActive: boolean;
  createdAt: Date;
  category?: Category;
}

export interface Submission {
  id: number;
  title: string;
  description?: string;
  content: string;
  contentType: 'photo' | 'video' | 'music' | 'lyrics';
  userId: number;
  competitionId: number;
  averageRating: number;
  totalRatings: number;
  createdAt: Date;
  user?: User;
  competition?: Competition;
}

export interface Rating {
  id: number;
  value: number;
  userId: number;
  submissionId: number;
  createdAt: Date;
}

export interface LeaderboardEntry extends Submission {
  user: User;
}
