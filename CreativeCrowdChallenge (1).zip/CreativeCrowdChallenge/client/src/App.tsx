import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import MobileNavigation from "@/components/layout/mobile-navigation";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import SubmissionsPage from "@/pages/submissions/index";
import SubmissionPage from "@/pages/submissions/[id]";
import CompetitionsPage from "@/pages/competitions/index";
import CompetitionPage from "@/pages/competitions/[id]";
import SubmitPage from "@/pages/submit";
import LoginPage from "@/pages/auth/login";
import RegisterPage from "@/pages/auth/register";
import ProfilePage from "@/pages/profile";
import SuggestCategoryPage from "@/pages/suggest-category";
import { useState } from "react";
import { User } from "./lib/types";

function App() {
  const [user, setUser] = useState<User | null>(null);

  const login = (userData: User) => {
    setUser(userData);
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen flex flex-col">
        <Header user={user} onLogout={logout} />
        
        <main className="flex-grow mt-16 pb-16 md:pb-0">
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/submissions">
              {() => <SubmissionsPage user={user} />}
            </Route>
            <Route path="/submissions/:id">
              {(params) => <SubmissionPage id={params.id} user={user} />}
            </Route>
            <Route path="/competitions">
              {() => <CompetitionsPage user={user} />}
            </Route>
            <Route path="/competitions/:id">
              {(params) => <CompetitionPage id={params.id} user={user} />}
            </Route>
            <Route path="/submit">
              {() => <SubmitPage user={user} />}
            </Route>
            <Route path="/login">
              {() => <LoginPage onLogin={login} />}
            </Route>
            <Route path="/register">
              {() => <RegisterPage onLogin={login} />}
            </Route>
            <Route path="/profile">
              {() => <ProfilePage user={user} />}
            </Route>
            <Route path="/suggest-category">
              {() => <SuggestCategoryPage user={user} />}
            </Route>
            <Route component={NotFound} />
          </Switch>
        </main>
        
        <Footer />
        <MobileNavigation />
      </div>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
