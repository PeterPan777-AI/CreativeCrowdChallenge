import { Link } from 'wouter';
import { Submission, User } from '@/lib/types';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Camera, Video, Headphones, Mic, Play } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import Rating from '@/components/ui/rating';
import { cn } from '@/lib/utils';
import { useQuery } from '@tanstack/react-query';

interface SubmissionCardProps {
  submission: Submission;
  user?: User;
}

const SubmissionCard = ({ submission, user }: SubmissionCardProps) => {
  const { data: userData } = useQuery({
    queryKey: ['/api/users', submission.userId],
    queryFn: async () => {
      const response = await fetch(`/api/users/${submission.userId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch user data');
      }
      return response.json();
    },
    enabled: !submission.user && !user,
  });

  const submissionUser = submission.user || user || userData;

  const getContentTypeIcon = () => {
    switch (submission.contentType) {
      case 'photo':
        return <Camera className="mr-1 h-3 w-3" />;
      case 'video':
        return <Video className="mr-1 h-3 w-3" />;
      case 'music':
        return <Headphones className="mr-1 h-3 w-3" />;
      case 'lyrics':
        return <Mic className="mr-1 h-3 w-3" />;
      default:
        return null;
    }
  };

  const getContentTypeLabel = () => {
    switch (submission.contentType) {
      case 'photo':
        return 'Photography';
      case 'video':
        return 'Video';
      case 'music':
        return 'Music';
      case 'lyrics':
        return 'Lyrics';
      default:
        return 'Unknown';
    }
  };

  const getInitials = (name: string = 'User') => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <Link href={`/submissions/${submission.id}`}>
        <a className="block relative">
          {submission.contentType === 'photo' && (
            <img 
              src={submission.content} 
              alt={submission.title} 
              className="w-full aspect-square object-cover"
            />
          )}
          
          {submission.contentType === 'video' && (
            <div className="relative">
              <img 
                src={submission.content.split(',')[0]} // Assuming the first item is the thumbnail URL
                alt={submission.title} 
                className="w-full aspect-square object-cover"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-14 h-14 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center">
                  <Play className="h-6 w-6 text-white fill-white" />
                </div>
              </div>
            </div>
          )}
          
          {submission.contentType === 'music' && (
            <div className="relative bg-gradient-to-r from-purple-500 to-indigo-600 aspect-square flex flex-col items-center justify-center p-6 text-white">
              <div className="w-24 h-24 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center mb-4">
                <Headphones className="h-10 w-10 text-white" />
              </div>
              <h4 className="text-xl font-bold mb-1 text-center">{submission.title}</h4>
              <p className="text-white/80 text-sm mb-4 text-center">
                {submission.description?.substring(0, 30) || 'Audio track'}
              </p>
              <div className="w-full bg-white/20 h-2 rounded-full overflow-hidden">
                <div className="bg-white h-full w-3/4 rounded-full"></div>
              </div>
            </div>
          )}
          
          {submission.contentType === 'lyrics' && (
            <div className="relative bg-gradient-to-r from-pink-500 to-rose-500 aspect-square flex flex-col items-center justify-center p-6 text-white">
              <div className="w-24 h-24 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center mb-4">
                <Mic className="h-10 w-10 text-white" />
              </div>
              <h4 className="text-xl font-bold mb-1 text-center">{submission.title}</h4>
              <div className="text-white/90 text-sm text-center overflow-hidden h-24">
                <p className="line-clamp-6">{submission.description || submission.content}</p>
              </div>
            </div>
          )}
          
          <div className="absolute bottom-3 left-3 flex items-center space-x-2">
            <div className="bg-black/50 backdrop-blur-sm text-white text-xs px-2 py-1 rounded-full">
              {getContentTypeIcon()} {getContentTypeLabel()}
            </div>
          </div>
        </a>
      </Link>
      
      <div className="p-4">
        <div className="flex justify-between items-start mb-3">
          <div>
            <Link href={`/submissions/${submission.id}`}>
              <a className="hover:underline">
                <h3 className="font-medium text-lg">{submission.title}</h3>
              </a>
            </Link>
            {submission.competition && (
              <p className="text-gray-500 text-sm">{submission.competition.title}</p>
            )}
          </div>
          
          <div className={cn(
            "flex items-center px-2 py-1 rounded font-medium",
            submission.averageRating > 0 ? "bg-primary/10 text-primary" : "bg-gray-100 text-gray-500"
          )}>
            <span className="text-xs mr-1">★</span>
            <span>{submission.averageRating ? submission.averageRating.toFixed(1) : '-'}</span>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          {submissionUser ? (
            <Link href={`/profile/${submissionUser.id}`}>
              <a className="flex items-center space-x-2">
                <Avatar className="h-7 w-7">
                  {submissionUser.profilePicture ? (
                    <AvatarImage src={submissionUser.profilePicture} alt={submissionUser.displayName} />
                  ) : (
                    <AvatarFallback>{getInitials(submissionUser.displayName)}</AvatarFallback>
                  )}
                </Avatar>
                <span className="text-sm font-medium">{submissionUser.displayName}</span>
              </a>
            </Link>
          ) : (
            <div className="flex items-center space-x-2">
              <Avatar className="h-7 w-7">
                <AvatarFallback>U</AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium">Unknown User</span>
            </div>
          )}
          
          <div className="text-sm text-gray-500">
            {formatDistanceToNow(new Date(submission.createdAt), { addSuffix: true })}
          </div>
        </div>
        
        <div className="mt-4 border-t pt-4">
          <Rating 
            submissionId={submission.id} 
            userId={user?.id}
            initialRating={0}
            readOnly={!user}
          />
        </div>
      </div>
    </div>
  );
};

export default SubmissionCard;
