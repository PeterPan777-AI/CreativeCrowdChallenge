import { useQuery } from '@tanstack/react-query';
import { Submission } from '@/lib/types';
import SubmissionCard from '@/components/submission/submission-card';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { useCallback, useState } from 'react';
import { Camera, Video, Headphones, Mic } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PopularSubmissionsProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

const PopularSubmissions = ({ selectedCategory, onCategoryChange }: PopularSubmissionsProps) => {
  const [limit, setLimit] = useState(6);
  
  const { data: submissions, isLoading, error } = useQuery<Submission[]>({
    queryKey: ['/api/submissions', { popular: true, limit }],
    queryFn: async () => {
      const response = await fetch(`/api/submissions?popular=true&limit=${limit}`);
      if (!response.ok) {
        throw new Error('Failed to fetch popular submissions');
      }
      return response.json();
    }
  });

  const filteredSubmissions = submissions?.filter(submission => {
    if (selectedCategory === 'all') return true;
    return submission.contentType === selectedCategory.toLowerCase();
  });

  const handleLoadMore = useCallback(() => {
    setLimit(prev => prev + 6);
  }, []);

  return (
    <section className="py-10 px-4 bg-gray-50">
      <div className="container mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Popular Submissions</h2>
          <div className="flex space-x-1">
            <div className="flex bg-white rounded-full p-1 shadow-sm overflow-x-auto">
              <button 
                className={cn(
                  "tab px-4 py-2 text-sm rounded-full",
                  selectedCategory === 'all' 
                    ? "bg-primary text-white" 
                    : "text-gray-700 hover:bg-gray-100"
                )}
                onClick={() => onCategoryChange('all')}
              >
                All
              </button>
              <button 
                className={cn(
                  "tab px-4 py-2 text-sm rounded-full",
                  selectedCategory === 'photo' 
                    ? "bg-primary text-white" 
                    : "text-gray-700 hover:bg-gray-100"
                )}
                onClick={() => onCategoryChange('photo')}
              >
                <Camera className="h-3 w-3 inline-block mr-1" />
                Photos
              </button>
              <button 
                className={cn(
                  "tab px-4 py-2 text-sm rounded-full",
                  selectedCategory === 'video' 
                    ? "bg-primary text-white" 
                    : "text-gray-700 hover:bg-gray-100"
                )}
                onClick={() => onCategoryChange('video')}
              >
                <Video className="h-3 w-3 inline-block mr-1" />
                Videos
              </button>
              <button 
                className={cn(
                  "tab px-4 py-2 text-sm rounded-full",
                  selectedCategory === 'music' 
                    ? "bg-primary text-white" 
                    : "text-gray-700 hover:bg-gray-100"
                )}
                onClick={() => onCategoryChange('music')}
              >
                <Headphones className="h-3 w-3 inline-block mr-1" />
                Music
              </button>
              <button 
                className={cn(
                  "tab px-4 py-2 text-sm rounded-full",
                  selectedCategory === 'lyrics' 
                    ? "bg-primary text-white" 
                    : "text-gray-700 hover:bg-gray-100"
                )}
                onClick={() => onCategoryChange('lyrics')}
              >
                <Mic className="h-3 w-3 inline-block mr-1" />
                Lyrics
              </button>
            </div>
          </div>
        </div>
        
        {error ? (
          <div className="bg-red-50 text-red-500 p-4 rounded-md">
            Error loading submissions. Please try again later.
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {isLoading ? (
                // Skeleton loading state
                Array(6).fill(null).map((_, index) => (
                  <div key={index} className="bg-white rounded-xl shadow-sm overflow-hidden">
                    <Skeleton className="w-full aspect-square" />
                    <div className="p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <Skeleton className="h-6 w-40 mb-1" />
                          <Skeleton className="h-4 w-32" />
                        </div>
                        <Skeleton className="h-8 w-12 rounded" />
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Skeleton className="h-7 w-7 rounded-full" />
                          <Skeleton className="h-4 w-24" />
                        </div>
                        <Skeleton className="h-4 w-16" />
                      </div>
                      <div className="mt-4 border-t pt-4">
                        <Skeleton className="h-6 w-full" />
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                filteredSubmissions?.map(submission => (
                  <SubmissionCard key={submission.id} submission={submission} />
                ))
              )}
              
              {!isLoading && filteredSubmissions?.length === 0 && (
                <div className="col-span-1 sm:col-span-2 lg:col-span-3 text-center py-10">
                  <p className="text-gray-500">No submissions found for this category. Be the first to submit!</p>
                </div>
              )}
            </div>
            
            {!isLoading && filteredSubmissions && filteredSubmissions.length > 0 && filteredSubmissions.length % 6 === 0 && (
              <div className="mt-8 text-center">
                <Button 
                  variant="outline"
                  onClick={handleLoadMore}
                  className="bg-white hover:bg-gray-50 text-primary font-medium px-6 py-3 rounded-full border border-gray-200 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 transition h-auto"
                >
                  Load More Submissions
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </section>
  );
};

export default PopularSubmissions;
