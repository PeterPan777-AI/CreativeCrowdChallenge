import { useQuery } from '@tanstack/react-query';
import { Competition, Category } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import { format } from 'date-fns';
import { Camera, Video, Headphones, Mic, FileText } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Link } from 'wouter';

const UpcomingCompetitions = () => {
  const { data: competitions, isLoading: loadingCompetitions } = useQuery<Competition[]>({
    queryKey: ['/api/competitions', { active: true }],
    queryFn: async () => {
      const response = await fetch('/api/competitions?active=true');
      if (!response.ok) {
        throw new Error('Failed to fetch competitions');
      }
      return response.json();
    }
  });

  const { data: categories, isLoading: loadingCategories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
    queryFn: async () => {
      const response = await fetch('/api/categories');
      if (!response.ok) {
        throw new Error('Failed to fetch categories');
      }
      return response.json();
    }
  });

  const getCategoryIcon = (categoryName: string) => {
    switch (categoryName?.toLowerCase()) {
      case 'photography':
        return <Camera className="h-4 w-4" />;
      case 'video':
        return <Video className="h-4 w-4" />;
      case 'music':
        return <Headphones className="h-4 w-4" />;
      case 'lyrics':
        return <Mic className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (categoryName: string) => {
    switch (categoryName?.toLowerCase()) {
      case 'photography':
        return 'bg-blue-100 text-blue-600';
      case 'video':
        return 'bg-green-100 text-green-600';
      case 'music':
        return 'bg-purple-100 text-purple-600';
      case 'lyrics':
        return 'bg-pink-100 text-pink-600';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  };

  const getCategoryName = (categoryId: number) => {
    return categories?.find(cat => cat.id === categoryId)?.name || 'Unknown';
  };

  const isLoading = loadingCompetitions || loadingCategories;

  return (
    <section className="py-10 px-4 bg-gray-50">
      <div className="container mx-auto">
        <h2 className="text-2xl font-bold mb-6">Upcoming Competitions</h2>
        
        <div className="overflow-x-auto">
          <div className="inline-block min-w-full align-middle">
            <div className="overflow-hidden shadow-sm ring-1 ring-black ring-opacity-5 rounded-lg">
              <table className="min-w-full divide-y divide-gray-200 bg-white">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Competition</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Prize</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Start Date</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">End Date</th>
                    <th scope="col" className="relative px-6 py-3">
                      <span className="sr-only">Action</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {isLoading ? (
                    // Skeleton loading state
                    Array(3).fill(null).map((_, index) => (
                      <tr key={index}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <Skeleton className="h-10 w-10 rounded" />
                            <div className="ml-4">
                              <Skeleton className="h-5 w-32 mb-1" />
                              <Skeleton className="h-4 w-24" />
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Skeleton className="h-6 w-24 rounded-full" />
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Skeleton className="h-5 w-16" />
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Skeleton className="h-5 w-24" />
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Skeleton className="h-5 w-24" />
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right">
                          <Skeleton className="h-5 w-16 ml-auto" />
                        </td>
                      </tr>
                    ))
                  ) : (
                    competitions && categories && competitions.length > 0 ? (
                      competitions.map(competition => {
                        const categoryName = getCategoryName(competition.categoryId);
                        return (
                          <tr key={competition.id}>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <div className={cn("h-10 w-10 flex-shrink-0 rounded flex items-center justify-center", getCategoryColor(categoryName))}>
                                  {getCategoryIcon(categoryName)}
                                </div>
                                <div className="ml-4">
                                  <div className="text-sm font-medium text-gray-900">{competition.title}</div>
                                  <div className="text-sm text-gray-500">
                                    {competition.sponsoredBy ? `Sponsored by ${competition.sponsoredBy}` : 'Community competition'}
                                  </div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={cn(
                                "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
                                getCategoryColor(categoryName)
                              )}>
                                {categoryName}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {competition.prizeAmount ? `$${competition.prizeAmount.toLocaleString()}` : 'Recognition'}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {format(new Date(competition.startDate), 'MMM d, yyyy')}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {format(new Date(competition.endDate), 'MMM d, yyyy')}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                              <Link href={`/competitions/${competition.id}`} className="text-accent hover:text-accent-dark">
                                Remind me
                              </Link>
                            </td>
                          </tr>
                        );
                      })
                    ) : (
                      <tr>
                        <td colSpan={6} className="px-6 py-10 text-center text-gray-500">
                          No upcoming competitions found. Check back soon!
                        </td>
                      </tr>
                    )
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default UpcomingCompetitions;
