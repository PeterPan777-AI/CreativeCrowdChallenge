import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { LeaderboardEntry } from '@/lib/types';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { ChevronRight, Star } from 'lucide-react';

const LeaderboardSection = () => {
  const { data: leaderboard, isLoading, error } = useQuery<LeaderboardEntry[]>({
    queryKey: ['/api/leaderboard', { limit: 4 }],
    queryFn: async () => {
      const response = await fetch('/api/leaderboard?limit=4');
      if (!response.ok) {
        throw new Error('Failed to fetch leaderboard');
      }
      return response.json();
    }
  });

  if (error) {
    return (
      <section className="py-10 px-4">
        <div className="container mx-auto">
          <h2 className="text-2xl font-bold mb-6">Weekly Leaderboard</h2>
          <div className="bg-red-50 text-red-500 p-4 rounded-md">
            Error loading leaderboard. Please try again later.
          </div>
        </div>
      </section>
    );
  }

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };

  return (
    <section className="py-10 px-4">
      <div className="container mx-auto">
        <h2 className="text-2xl font-bold mb-6">Weekly Leaderboard</h2>
        
        <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
          <div className="flex flex-col md:flex-row">
            {isLoading ? (
              <>
                <div className="md:w-2/5 relative overflow-hidden">
                  <Skeleton className="w-full h-80 md:h-full" />
                </div>
                <div className="md:w-3/5 p-6">
                  <Skeleton className="h-6 w-40 mb-4" />
                  <div className="space-y-4">
                    {Array(3).fill(null).map((_, i) => (
                      <div key={i} className="flex items-center p-3 rounded-lg">
                        <Skeleton className="h-8 w-8 rounded-full mr-4" />
                        <div className="flex-grow">
                          <Skeleton className="h-5 w-32 mb-1" />
                          <Skeleton className="h-4 w-24" />
                        </div>
                        <Skeleton className="h-8 w-16 rounded" />
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 pt-4 border-t">
                    <Skeleton className="h-5 w-56" />
                  </div>
                </div>
              </>
            ) : (
              <>
                {leaderboard && leaderboard.length > 0 ? (
                  <>
                    {/* Winner card */}
                    <div className="md:w-2/5 relative overflow-hidden">
                      <div className="absolute top-0 left-0 w-full h-full">
                        <img 
                          src={leaderboard[0].content} 
                          alt={leaderboard[0].title} 
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-6 text-white">
                          <div className="bg-accent px-3 py-1 rounded-full text-xs inline-block mb-2 w-fit">
                            <span className="mr-1">🏆</span> 1st Place
                          </div>
                          <h3 className="text-xl font-bold mb-1">{leaderboard[0].title}</h3>
                          <p className="text-white/80 text-sm mb-2">
                            {leaderboard[0].competition?.title || 'Competition'}
                          </p>
                          <div className="flex items-center space-x-2">
                            <Avatar className="w-7 h-7 border-2 border-white">
                              {leaderboard[0].user?.profilePicture ? (
                                <AvatarImage 
                                  src={leaderboard[0].user.profilePicture} 
                                  alt={leaderboard[0].user.displayName} 
                                />
                              ) : (
                                <AvatarFallback>{getInitials(leaderboard[0].user.displayName)}</AvatarFallback>
                              )}
                            </Avatar>
                            <span className="text-sm">{leaderboard[0].user.displayName}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {/* Runners up */}
                    <div className="md:w-3/5 p-6">
                      <h3 className="font-bold mb-4">Top Performers</h3>
                      <div className="space-y-4">
                        {leaderboard.slice(1, 4).map((entry, index) => (
                          <Link key={entry.id} href={`/submissions/${entry.id}`}>
                            <a className="flex items-center p-3 rounded-lg hover:bg-gray-50 transition">
                              <div className="font-bold text-xl text-gray-400 w-6">{index + 2}</div>
                              <Avatar className="w-10 h-10 mx-4">
                                {entry.user?.profilePicture ? (
                                  <AvatarImage 
                                    src={entry.user.profilePicture} 
                                    alt={entry.user.displayName} 
                                  />
                                ) : (
                                  <AvatarFallback>{getInitials(entry.user.displayName)}</AvatarFallback>
                                )}
                              </Avatar>
                              <div className="flex-grow">
                                <h4 className="font-medium">{entry.user.displayName}</h4>
                                <p className="text-gray-500 text-sm">{entry.title}</p>
                              </div>
                              <div className="flex items-center bg-primary/10 px-3 py-1 rounded text-primary font-medium">
                                <Star className="h-3 w-3 mr-1 fill-current" />
                                <span>{entry.averageRating.toFixed(1)}</span>
                              </div>
                            </a>
                          </Link>
                        ))}
                      </div>
                      
                      <div className="mt-4 pt-4 border-t">
                        <Link href="/leaderboard">
                          <a className="text-primary font-medium hover:underline flex items-center">
                            View complete leaderboard
                            <ChevronRight className="ml-1 h-4 w-4" />
                          </a>
                        </Link>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="w-full p-10 text-center">
                    <p className="text-gray-500">No submissions have been rated yet. Be the first to rate!</p>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default LeaderboardSection;
