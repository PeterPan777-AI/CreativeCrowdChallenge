import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Competition } from '@/lib/types';
import CompetitionCard from '@/components/competition/competition-card';
import { Skeleton } from '@/components/ui/skeleton';

const FeaturedCompetitions = () => {
  const { data: competitions, isLoading, error } = useQuery<Competition[]>({
    queryKey: ['/api/competitions', { active: true }],
    queryFn: async () => {
      const response = await fetch('/api/competitions?active=true');
      if (!response.ok) {
        throw new Error('Failed to fetch competitions');
      }
      return response.json();
    }
  });

  if (error) {
    return (
      <section className="py-10 px-4">
        <div className="container mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-bold">Featured Competitions</h2>
          </div>
          <div className="bg-red-50 text-red-500 p-4 rounded-md">
            Error loading competitions. Please try again later.
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-10 px-4">
      <div className="container mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-bold">Featured Competitions</h2>
          <Link href="/competitions" className="text-primary font-medium hover:underline">
            View All
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            // Skeleton loading state
            Array(3).fill(null).map((_, index) => (
              <div key={index} className="bg-white rounded-xl shadow-sm overflow-hidden">
                <Skeleton className="h-36 w-full" />
                <div className="p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <Skeleton className="h-6 w-20" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                  <Skeleton className="h-6 w-3/4 mb-1" />
                  <Skeleton className="h-4 w-full mb-3" />
                  <div className="flex justify-between items-center">
                    <Skeleton className="h-5 w-24" />
                    <Skeleton className="h-5 w-16" />
                  </div>
                </div>
              </div>
            ))
          ) : (
            competitions?.map((competition) => (
              <CompetitionCard key={competition.id} competition={competition} />
            ))
          )}

          {competitions && competitions.length === 0 && (
            <div className="col-span-3 text-center py-10">
              <p className="text-gray-500">No active competitions found. Check back soon!</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default FeaturedCompetitions;
