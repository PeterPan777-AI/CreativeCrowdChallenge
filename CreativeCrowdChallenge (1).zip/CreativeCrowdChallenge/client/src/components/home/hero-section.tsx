import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Plus, Trophy } from 'lucide-react';

const HeroSection = () => {
  return (
    <section className="bg-gradient-to-r from-primary to-secondary py-12 px-4">
      <div className="container mx-auto text-center text-white">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">Show Your Talent, Win Prizes</h1>
        <p className="text-lg md:text-xl opacity-90 mb-8 max-w-2xl mx-auto">
          Upload your creative work, get rated by the community, and compete for weekly prizes!
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Link href="/submit">
            <Button className="bg-accent hover:bg-accent-dark text-white px-6 py-3 rounded-full font-medium focus:outline-none focus:ring-2 focus:ring-accent focus:ring-offset-2 transition h-auto">
              <Plus className="h-4 w-4 mr-2" /> Submit Your Work
            </Button>
          </Link>
          <Link href="/competitions">
            <Button variant="outline" className="bg-white/20 hover:bg-white/30 text-white border-white/30 px-6 py-3 rounded-full font-medium focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 transition h-auto">
              <Trophy className="h-4 w-4 mr-2" /> View Competitions
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
