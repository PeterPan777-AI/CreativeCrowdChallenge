import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { UserPlus } from 'lucide-react';

const CTASection = () => {
  return (
    <section className="py-16 px-4 bg-gradient-to-r from-primary to-secondary">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl font-bold text-white mb-4">Ready to Showcase Your Talent?</h2>
        <p className="text-white/80 text-lg mb-8 max-w-2xl mx-auto">
          Join thousands of creators competing for recognition and prizes. Your next award-winning submission is just an upload away!
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Link href="/register">
            <Button variant="secondary" className="bg-white hover:bg-gray-100 text-primary px-6 py-3 rounded-full font-medium focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-primary transition h-auto">
              <UserPlus className="h-4 w-4 mr-2" /> Create Account
            </Button>
          </Link>
          <Link href="/competitions">
            <Button variant="outline" className="bg-white/20 hover:bg-white/30 text-white border-white/30 px-6 py-3 rounded-full font-medium focus:outline-none focus:ring-2 focus:ring-white/50 focus:ring-offset-2 focus:ring-offset-primary transition h-auto">
              Learn More
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
