import { Link } from 'wouter';
import { Competition, Category } from '@/lib/types';
import { useQuery } from '@tanstack/react-query';
import { formatDistanceToNow } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';
import CategoryBadge from '@/components/ui/category-badge';
import { Camera, Video, Headphones, Mic } from 'lucide-react';

interface CompetitionCardProps {
  competition: Competition;
}

const CompetitionCard = ({ competition }: CompetitionCardProps) => {
  const { data: category, isLoading } = useQuery<Category>({
    queryKey: ['/api/categories', competition.categoryId],
    queryFn: async () => {
      const response = await fetch(`/api/categories/${competition.categoryId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch category');
      }
      return response.json();
    },
  });

  const getTimeRemaining = () => {
    const now = new Date();
    const endDate = new Date(competition.endDate);
    
    if (endDate < now) {
      return 'Competition ended';
    }
    
    return `Ends in ${formatDistanceToNow(endDate)}`;
  };

  const getCategoryIcon = () => {
    if (!category) return null;
    
    switch (category.name.toLowerCase()) {
      case 'photography':
        return <Camera className="mr-1 h-3 w-3" />;
      case 'video':
        return <Video className="mr-1 h-3 w-3" />;
      case 'music':
        return <Headphones className="mr-1 h-3 w-3" />;
      case 'lyrics':
        return <Mic className="mr-1 h-3 w-3" />;
      default:
        return null;
    }
  };

  const getCategoryBackgroundImage = () => {
    if (!category) return '';
    
    switch (category.name.toLowerCase()) {
      case 'photography':
        return 'https://images.unsplash.com/photo-1452587925148-ce544e77e70d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80';
      case 'video':
        return 'https://images.unsplash.com/photo-1516280440614-37939bbacd81?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80';
      case 'music':
        return 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80';
      case 'lyrics':
        return 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80';
      default:
        return 'https://images.unsplash.com/photo-1455849318743-b2233052fcff?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition">
      <Link href={`/competitions/${competition.id}`} className="block h-36 bg-gray-200 relative">
        <img 
          src={getCategoryBackgroundImage()} 
          alt={competition.title} 
          className="w-full h-full object-cover"
        />
        <div className="absolute top-3 right-3 bg-accent text-white text-xs px-2 py-1 rounded-full">
          {getTimeRemaining()}
        </div>
      </Link>
      
      <div className="p-4">
        <div className="flex items-center space-x-2 mb-2">
          {isLoading ? (
            <>
              <Skeleton className="h-6 w-24 rounded" />
              <Skeleton className="h-4 w-12" />
            </>
          ) : (
            <>
              {category && (
                <CategoryBadge 
                  category={category.name} 
                  icon={getCategoryIcon()} 
                />
              )}
              <span className="text-xs text-gray-500">
                0 submissions
              </span>
            </>
          )}
        </div>
        
        <Link href={`/competitions/${competition.id}`} className="block hover:underline">
          <h3 className="font-bold text-lg mb-1">{competition.title}</h3>
        </Link>
        
        <p className="text-gray-600 text-sm mb-3 line-clamp-2">
          {competition.description}
        </p>
        
        <div className="flex justify-between items-center">
          {competition.prizeAmount ? (
            <span className="text-primary-dark font-medium">
              ${competition.prizeAmount} Prize
            </span>
          ) : (
            <span className="text-gray-500 font-medium">
              Recognition Award
            </span>
          )}
          
          <Link href={`/competitions/${competition.id}`} className="text-accent hover:text-accent-dark font-medium">
            Join Now
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CompetitionCard;
