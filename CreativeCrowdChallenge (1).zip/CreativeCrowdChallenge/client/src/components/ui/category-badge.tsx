import { cn } from '@/lib/utils';

type CategoryColorMap = {
  [key: string]: {
    bg: string;
    text: string;
  };
};

const colorMap: CategoryColorMap = {
  Photography: { bg: 'bg-blue-100', text: 'text-blue-800' },
  Video: { bg: 'bg-green-100', text: 'text-green-800' },
  Music: { bg: 'bg-purple-100', text: 'text-purple-800' },
  Lyrics: { bg: 'bg-pink-100', text: 'text-pink-800' },
  all: { bg: 'bg-gray-100', text: 'text-gray-800' },
};

interface CategoryBadgeProps {
  category: string;
  className?: string;
  icon?: React.ReactNode;
}

export const CategoryBadge = ({ category, className, icon }: CategoryBadgeProps) => {
  const colors = colorMap[category] || { bg: 'bg-gray-100', text: 'text-gray-800' };
  
  return (
    <span 
      className={cn(
        'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium',
        colors.bg,
        colors.text,
        className
      )}
    >
      {icon && <span className="mr-1">{icon}</span>}
      {category}
    </span>
  );
};

export default CategoryBadge;
