import { useState } from 'react';
import { cn } from '@/lib/utils';
import { Star } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useMutation, useQueryClient } from '@tanstack/react-query';

interface RatingProps {
  submissionId: number;
  userId?: number;
  initialRating?: number;
  size?: 'sm' | 'md' | 'lg';
  readOnly?: boolean;
}

export const Rating = ({
  submissionId,
  userId,
  initialRating = 0,
  size = 'md',
  readOnly = false,
}: RatingProps) => {
  const [hover, setHover] = useState<number | null>(null);
  const [rating, setRating] = useState<number>(initialRating);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const sizeClass = {
    sm: 'text-sm',
    md: 'text-lg',
    lg: 'text-xl',
  };

  const rateMutation = useMutation({
    mutationFn: async (value: number) => {
      if (!userId) {
        toast({
          title: "Authentication required",
          description: "Please log in to rate submissions",
          variant: "destructive",
        });
        return;
      }

      await apiRequest('POST', '/api/ratings', {
        value,
        userId,
        submissionId,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/submissions', submissionId] });
      queryClient.invalidateQueries({ queryKey: ['/api/submissions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/leaderboard'] });
      
      toast({
        title: "Rating submitted",
        description: "Thank you for rating this submission!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit rating. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleRating = (value: number) => {
    if (readOnly) return;
    
    setRating(value);
    rateMutation.mutate(value);
  };

  return (
    <div className="flex items-center justify-between">
      <div className="text-sm text-gray-500">
        {readOnly ? 'Rating:' : 'Rate this submission:'}
      </div>
      <div className="flex space-x-1">
        {[...Array(10)].map((_, i) => {
          const ratingValue = i + 1;
          return (
            <Star
              key={i}
              className={cn(
                'rating-star',
                sizeClass[size],
                (hover !== null && hover >= ratingValue) || (hover === null && rating >= ratingValue)
                  ? 'text-amber-500 fill-amber-500'
                  : 'text-gray-300',
                !readOnly && 'cursor-pointer'
              )}
              onMouseEnter={() => !readOnly && setHover(ratingValue)}
              onMouseLeave={() => !readOnly && setHover(null)}
              onClick={() => !readOnly && handleRating(ratingValue)}
            />
          );
        })}
      </div>
    </div>
  );
};

export default Rating;
