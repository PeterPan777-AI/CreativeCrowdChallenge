import { Link } from 'wouter';
import { FaInstagram, FaTwitter, FaTiktok, FaYoutube } from 'react-icons/fa';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-12 px-4">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">CreativeCompete</h3>
            <p className="text-gray-400 mb-4">The platform for creative competitions and talent showcase.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition">
                <FaInstagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <FaTwitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <FaTiktok className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <FaYoutube className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Competitions</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/competitions?category=Photography" className="text-gray-400 hover:text-white transition">
                  Photography
                </Link>
              </li>
              <li>
                <Link href="/competitions?category=Video" className="text-gray-400 hover:text-white transition">
                  Video
                </Link>
              </li>
              <li>
                <Link href="/competitions?category=Music" className="text-gray-400 hover:text-white transition">
                  Music
                </Link>
              </li>
              <li>
                <Link href="/competitions?category=Lyrics" className="text-gray-400 hover:text-white transition">
                  Lyrics
                </Link>
              </li>
              <li>
                <Link href="/competitions" className="text-gray-400 hover:text-white transition">
                  Creative Writing
                </Link>
              </li>
              <li>
                <Link href="/suggest-category" className="text-gray-400 hover:text-white transition">
                  Suggest a Category
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Company</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">About Us</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">Careers</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">Blog</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">Press</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">Contact</a>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Resources</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">Help Center</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">Community Guidelines</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">Terms of Service</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">Privacy Policy</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">Cookie Policy</a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-gray-700 text-center text-gray-400 text-sm">
          <p>&copy; {new Date().getFullYear()} VoteMe. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
