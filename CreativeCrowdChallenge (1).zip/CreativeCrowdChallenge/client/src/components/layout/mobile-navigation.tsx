import { Link, useLocation } from 'wouter';
import { Home, Search, Plus, Bell, User } from 'lucide-react';
import { cn } from '@/lib/utils';

const MobileNavigation = () => {
  const [location] = useLocation();

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-10">
      <div className="flex justify-around items-center">
        <Link href="/" className={cn(
            "flex flex-col items-center py-3 px-4",
            isActive("/") ? "text-primary" : "text-gray-500"
          )}>
            <Home className="h-5 w-5" />
            <span className="text-xs mt-1">Home</span>
        </Link>
        
        <Link href="/competitions" className={cn(
            "flex flex-col items-center py-3 px-4",
            isActive("/competitions") ? "text-primary" : "text-gray-500"
          )}>
            <Search className="h-5 w-5" />
            <span className="text-xs mt-1">Discover</span>
        </Link>
        
        <Link href="/submit" className="flex flex-col items-center py-3 px-4">
          <div className="bg-accent text-white rounded-full w-14 h-14 flex items-center justify-center -mt-5">
            <Plus className="h-6 w-6" />
          </div>
        </Link>
        
        <Link href="/notifications" className={cn(
            "flex flex-col items-center py-3 px-4",
            isActive("/notifications") ? "text-primary" : "text-gray-500"
          )}>
            <Bell className="h-5 w-5" />
            <span className="text-xs mt-1">Notifications</span>
        </Link>
        
        <Link href="/profile" className={cn(
            "flex flex-col items-center py-3 px-4",
            isActive("/profile") ? "text-primary" : "text-gray-500"
          )}>
            <User className="h-5 w-5" />
            <span className="text-xs mt-1">Profile</span>
        </Link>
      </div>
    </div>
  );
};

export default MobileNavigation;
