import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { User } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { PlusIcon, SearchIcon, Menu } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Input } from '@/components/ui/input';

interface HeaderProps {
  user: User | null;
  onLogout: () => void;
}

const Header = ({ user, onLogout }: HeaderProps) => {
  const [location, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };

  return (
    <header className="bg-white shadow-sm fixed top-0 left-0 right-0 z-10">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/" className="text-primary font-bold text-xl">
            VoteMe
          </Link>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="lg:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <div className="py-4 space-y-4">
                  <form onSubmit={handleSearch} className="relative">
                    <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      type="text"
                      placeholder="Search competitions..."
                      className="pl-10 pr-4 py-2 w-full"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </form>
                  
                  <div className="space-y-2">
                    <Link href="/" className="block px-2 py-1 hover:bg-gray-100 rounded">
                      Home
                    </Link>
                    <Link href="/competitions" className="block px-2 py-1 hover:bg-gray-100 rounded">
                      Competitions
                    </Link>
                    <Link href="/submissions" className="block px-2 py-1 hover:bg-gray-100 rounded">
                      Submissions
                    </Link>
                    
                    {user ? (
                      <>
                        <Link href="/profile" className="block px-2 py-1 hover:bg-gray-100 rounded">
                          Profile
                        </Link>
                        <button 
                          onClick={onLogout}
                          className="block w-full text-left px-2 py-1 hover:bg-gray-100 rounded text-red-500"
                        >
                          Logout
                        </button>
                      </>
                    ) : (
                      <>
                        <Link href="/login" className="block px-2 py-1 hover:bg-gray-100 rounded">
                          Login
                        </Link>
                        <Link href="/register" className="block px-2 py-1 hover:bg-gray-100 rounded">
                          Register
                        </Link>
                      </>
                    )}
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
          
          <button className="lg:hidden focus:outline-none">
            <SearchIcon className="h-5 w-5 text-gray-500" />
          </button>
          
          <div className="hidden lg:block relative">
            <form onSubmit={handleSearch}>
              <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input 
                type="text" 
                placeholder="Search competitions..." 
                className="pl-10 pr-4 py-2 rounded-full bg-gray-100 focus:outline-none focus:ring-2 focus:ring-primary focus:bg-white w-64"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </form>
          </div>
          
          <Link href="/submit">
            <Button className="bg-primary hover:bg-primary-dark text-white rounded-full text-sm font-medium focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 hidden sm:flex">
              <PlusIcon className="h-4 w-4 mr-1" /> Submit
            </Button>
          </Link>
          
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-9 w-9 rounded-full" size="icon">
                  <Avatar className="h-9 w-9">
                    {user.profilePicture ? (
                      <AvatarImage src={user.profilePicture} alt={user.displayName} />
                    ) : (
                      <AvatarFallback>{getInitials(user.displayName)}</AvatarFallback>
                    )}
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <div className="flex items-center justify-start gap-2 p-2">
                  <div className="flex flex-col space-y-1 leading-none">
                    <p className="font-medium">{user.displayName}</p>
                    <p className="text-sm text-muted-foreground">@{user.username}</p>
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <Link href="/profile">
                    Profile
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Link href={`/submissions?userId=${user.id}`}>
                    My Submissions
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={onLogout} className="text-red-500 cursor-pointer">
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <div className="flex items-center space-x-2">
              <Link href="/login">
                <Button variant="ghost" size="sm">Login</Button>
              </Link>
              <Link href="/register">
                <Button size="sm">Register</Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
