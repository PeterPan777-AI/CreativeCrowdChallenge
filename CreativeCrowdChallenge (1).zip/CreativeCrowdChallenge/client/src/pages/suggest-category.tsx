import { useState } from 'react';
import { useLocation } from 'wouter';
import { User } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from '@/components/ui/form';
import { insertCategorySuggestionSchema } from '../../../shared/schema';

interface SuggestCategoryPageProps {
  user: User | null;
}

const SuggestCategoryPage = ({ user }: SuggestCategoryPageProps) => {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form validation schema - extending the insert schema
  const formSchema = insertCategorySuggestionSchema.extend({
    name: z.string().min(3, "Category name must be at least 3 characters").max(50, "Category name must be less than 50 characters"),
    description: z.string().min(10, "Description must be at least 10 characters").max(500, "Description must be less than 500 characters"),
  });

  // Redirect if not logged in
  if (!user) {
    toast({
      title: "Login required",
      description: "You need to be logged in to suggest a new category",
      variant: "destructive",
    });
    navigate("/login?returnUrl=/suggest-category");
    return null;
  }

  // Setup form
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: "",
      userId: user.id,
    },
  });

  // Handle form submission
  const onSubmit = async (data: z.infer<typeof formSchema>) => {
    setIsSubmitting(true);
    
    try {
      await apiRequest('POST', '/api/category-suggestions', data);
      
      toast({
        title: "Suggestion submitted",
        description: "Thank you for your suggestion! We'll review it soon.",
      });
      
      navigate("/competitions");
    } catch (error) {
      console.error('Submission error:', error);
      toast({
        title: "Submission failed",
        description: "There was an error submitting your suggestion. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-16 flex justify-center">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center">Suggest a New Category</CardTitle>
          <CardDescription className="text-center">
            Have an idea for a new competition category? Share it with us!
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category Name</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="e.g., Digital Art, Poetry, Animation"
                        {...field}
                        disabled={isSubmitting}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Describe what this category is about and why it would make a good addition..."
                        className="min-h-[120px]"
                        {...field}
                        disabled={isSubmitting}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <Button 
                type="submit" 
                className="w-full bg-primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? "Submitting..." : "Submit Suggestion"}
              </Button>
            </form>
          </Form>
        </CardContent>
        
        <CardFooter className="flex flex-col space-y-2">
          <div className="text-center text-sm text-gray-500">
            Our team will review your suggestion and may add it to the platform.
          </div>
        </CardFooter>
      </Card>
    </div>
  );
};

export default SuggestCategoryPage;