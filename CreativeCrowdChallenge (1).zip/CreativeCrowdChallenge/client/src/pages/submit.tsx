import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Competition, Category, User } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { apiRequest } from '@/lib/queryClient';
import { Camera, Music, Video, FileText, Upload, ArrowLeft } from 'lucide-react';

interface SubmitPageProps {
  user: User | null;
}

const SubmitPage = ({ user }: SubmitPageProps) => {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const [submissionType, setSubmissionType] = useState<string>('photo');
  const [uploadPreview, setUploadPreview] = useState<string | null>(null);
  
  // Parse query params
  const params = new URLSearchParams(location.split('?')[1] || '');
  const preselectedCompetitionId = params.get('competitionId');
  
  // Redirect if not logged in
  useEffect(() => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to submit your work",
        variant: "destructive",
      });
      navigate("/login");
    }
  }, [user, navigate, toast]);
  
  // Fetch competitions
  const { data: competitions, isLoading: loadingCompetitions } = useQuery<Competition[]>({
    queryKey: ['/api/competitions', { active: true }],
    queryFn: async () => {
      const response = await fetch('/api/competitions?active=true');
      if (!response.ok) {
        throw new Error('Failed to fetch competitions');
      }
      return response.json();
    },
    enabled: !!user,
  });
  
  // Fetch categories
  const { data: categories, isLoading: loadingCategories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
    queryFn: async () => {
      const response = await fetch('/api/categories');
      if (!response.ok) {
        throw new Error('Failed to fetch categories');
      }
      return response.json();
    },
    enabled: !!user,
  });
  
  // Form validation schema
  const formSchema = z.object({
    title: z.string().min(3, "Title must be at least 3 characters").max(100, "Title must be less than 100 characters"),
    description: z.string().max(500, "Description must be less than 500 characters").optional(),
    competitionId: z.string().min(1, "Please select a competition"),
    content: z.string().min(1, "Content is required"),
    contentType: z.string().min(1, "Content type is required")
  });
  
  // Form setup
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      competitionId: preselectedCompetitionId || "",
      content: "",
      contentType: submissionType
    }
  });
  
  // Update form when submission type changes
  useEffect(() => {
    form.setValue('contentType', submissionType);
  }, [submissionType, form]);
  
  // Update form when competition ID is preselected
  useEffect(() => {
    if (preselectedCompetitionId) {
      form.setValue('competitionId', preselectedCompetitionId);
    }
  }, [preselectedCompetitionId, form]);
  
  // Submission mutation
  const submitMutation = useMutation({
    mutationFn: async (data: z.infer<typeof formSchema>) => {
      const submissionData = {
        title: data.title,
        description: data.description || "",
        competitionId: parseInt(data.competitionId),
        content: data.content,
        contentType: data.contentType,
        userId: user?.id || 0
      };
      
      return await apiRequest('POST', '/api/submissions', submissionData);
    },
    onSuccess: async (response) => {
      const data = await response.json();
      toast({
        title: "Submission successful",
        description: "Your work has been submitted to the competition.",
      });
      navigate(`/submissions/${data.id}`);
    },
    onError: (error) => {
      console.error('Submission error:', error);
      toast({
        title: "Submission failed",
        description: "There was an error submitting your work. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  // Handle form submission
  const onSubmit = async (data: z.infer<typeof formSchema>) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to submit your work",
        variant: "destructive",
      });
      return;
    }
    
    submitMutation.mutate(data);
  };
  
  // Handle file upload
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    // For MVP, we're going to use a direct data URL
    // In a production app, we would upload to a storage service
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setUploadPreview(dataUrl);
      form.setValue('content', dataUrl);
    };
    reader.readAsDataURL(file);
  };
  
  // Prepare ContentType mapping
  const contentTypeMap = {
    photo: {
      label: "Photography",
      icon: <Camera className="h-5 w-5" />,
      acceptTypes: "image/*"
    },
    video: {
      label: "Video",
      icon: <Video className="h-5 w-5" />,
      acceptTypes: "video/*"
    },
    music: {
      label: "Music",
      icon: <Music className="h-5 w-5" />,
      acceptTypes: "audio/*"
    },
    lyrics: {
      label: "Lyrics",
      icon: <FileText className="h-5 w-5" />,
      acceptTypes: "text/*"
    }
  };
  
  const isLoading = loadingCompetitions || loadingCategories || submitMutation.isPending;
  
  if (!user) {
    return null; // Will redirect in useEffect
  }

  return (
    <div className="container mx-auto px-4 py-10">
      <div className="max-w-3xl mx-auto">
        <Button 
          variant="ghost" 
          className="mb-6"
          onClick={() => navigate('/competitions')}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to competitions
        </Button>
        
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Submit Your Work</h1>
          <p className="text-gray-600">Showcase your talent and participate in creative competitions</p>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">Choose Content Type</h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            {Object.entries(contentTypeMap).map(([type, { label, icon }]) => (
              <button
                key={type}
                className={`p-4 rounded-lg border transition-colors ${
                  submissionType === type 
                    ? 'border-primary bg-primary/5 text-primary' 
                    : 'border-gray-200 hover:border-gray-300'
                } flex flex-col items-center justify-center gap-2`}
                onClick={() => setSubmissionType(type)}
                type="button"
              >
                {icon}
                <span className="font-medium">{label}</span>
              </button>
            ))}
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-xl font-bold mb-6">Submission Details</h2>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Give your submission a title" 
                        {...field} 
                        disabled={isLoading}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Tell us about your work (optional)" 
                        {...field} 
                        disabled={isLoading}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="competitionId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Competition</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value} 
                      disabled={isLoading}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a competition" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {loadingCompetitions ? (
                          <div className="p-2">
                            <Skeleton className="h-5 w-full mb-2" />
                            <Skeleton className="h-5 w-full mb-2" />
                            <Skeleton className="h-5 w-full" />
                          </div>
                        ) : competitions && competitions.length > 0 ? (
                          competitions.map(competition => (
                            <SelectItem 
                              key={competition.id} 
                              value={competition.id.toString()}
                            >
                              {competition.title}
                            </SelectItem>
                          ))
                        ) : (
                          <div className="p-2 text-gray-500 text-center">
                            No active competitions found
                          </div>
                        )}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      {submissionType === 'lyrics' ? 'Lyrics' : 'Upload ' + contentTypeMap[submissionType as keyof typeof contentTypeMap].label}
                    </FormLabel>
                    <FormControl>
                      {submissionType === 'lyrics' ? (
                        <Textarea 
                          placeholder="Enter your lyrics here" 
                          className="min-h-[200px]"
                          onChange={(e) => {
                            field.onChange(e.target.value);
                          }}
                          value={field.value}
                          disabled={isLoading}
                        />
                      ) : (
                        <div className="space-y-4">
                          {!uploadPreview ? (
                            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-primary transition-colors">
                              <Input
                                type="file"
                                id="file-upload"
                                className="hidden"
                                accept={contentTypeMap[submissionType as keyof typeof contentTypeMap].acceptTypes}
                                onChange={handleFileUpload}
                                disabled={isLoading}
                              />
                              <label 
                                htmlFor="file-upload" 
                                className="cursor-pointer flex flex-col items-center"
                              >
                                <Upload className="h-10 w-10 text-gray-400 mb-2" />
                                <p className="font-medium text-gray-700">
                                  Click to upload 
                                  <span className="text-primary"> {contentTypeMap[submissionType as keyof typeof contentTypeMap].label}</span>
                                </p>
                                <p className="text-gray-500 text-sm mt-1">
                                  {submissionType === 'photo' && 'SVG, PNG, JPG or GIF'}
                                  {submissionType === 'video' && 'MP4, WebM or OGG'}
                                  {submissionType === 'music' && 'MP3, WAV or OGG'}
                                </p>
                              </label>
                            </div>
                          ) : (
                            <div className="relative">
                              {submissionType === 'photo' && (
                                <img 
                                  src={uploadPreview} 
                                  alt="Preview" 
                                  className="max-h-[300px] mx-auto rounded-lg"
                                />
                              )}
                              {submissionType === 'video' && (
                                <video 
                                  src={uploadPreview}
                                  controls
                                  className="max-h-[300px] w-full rounded-lg"
                                ></video>
                              )}
                              {submissionType === 'music' && (
                                <audio 
                                  src={uploadPreview}
                                  controls
                                  className="w-full"
                                ></audio>
                              )}
                              <Button
                                type="button"
                                variant="outline"
                                className="mt-2"
                                onClick={() => {
                                  setUploadPreview(null);
                                  field.onChange('');
                                }}
                                disabled={isLoading}
                              >
                                Replace
                              </Button>
                            </div>
                          )}
                          <input type="hidden" {...field} />
                        </div>
                      )}
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="pt-4 border-t border-gray-200">
                <Button 
                  type="submit" 
                  className="w-full md:w-auto" 
                  disabled={isLoading}
                >
                  {isLoading ? 'Submitting...' : 'Submit Your Work'}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
};

export default SubmitPage;
