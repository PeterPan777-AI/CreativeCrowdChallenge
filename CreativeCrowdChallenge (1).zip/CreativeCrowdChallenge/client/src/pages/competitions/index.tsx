import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Competition, Category } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import CompetitionCard from '@/components/competition/competition-card';
import { Camera, Video, Headphones, Mic, Search, Trophy } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';

interface CompetitionsPageProps {
  user: User | null;
}

const CompetitionsPage = ({ user }: CompetitionsPageProps) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Fetch categories
  const { data: categories, isLoading: loadingCategories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
    queryFn: async () => {
      const response = await fetch('/api/categories');
      if (!response.ok) {
        throw new Error('Failed to fetch categories');
      }
      return response.json();
    }
  });
  
  // Fetch competitions
  const { data: competitions, isLoading: loadingCompetitions, error } = useQuery<Competition[]>({
    queryKey: ['/api/competitions'],
    queryFn: async () => {
      const response = await fetch('/api/competitions');
      if (!response.ok) {
        throw new Error('Failed to fetch competitions');
      }
      return response.json();
    }
  });
  
  // Filter competitions by category and search query
  const filteredCompetitions = competitions?.filter(competition => {
    // Filter by category
    if (selectedCategory !== 'all') {
      const category = categories?.find(cat => cat.id === competition.categoryId);
      if (category?.name.toLowerCase() !== selectedCategory.toLowerCase()) {
        return false;
      }
    }
    
    // Filter by search query
    if (searchQuery.trim() !== '') {
      const query = searchQuery.toLowerCase();
      return (
        competition.title.toLowerCase().includes(query) ||
        competition.description.toLowerCase().includes(query) ||
        competition.sponsoredBy?.toLowerCase().includes(query)
      );
    }
    
    return true;
  });
  
  const isLoading = loadingCategories || loadingCompetitions;
  
  // Get category icon component
  const getCategoryIcon = (categoryName: string) => {
    switch (categoryName.toLowerCase()) {
      case 'photography':
        return <Camera className="h-3 w-3 inline-block mr-1" />;
      case 'video':
        return <Video className="h-3 w-3 inline-block mr-1" />;
      case 'music':
        return <Headphones className="h-3 w-3 inline-block mr-1" />;
      case 'lyrics':
        return <Mic className="h-3 w-3 inline-block mr-1" />;
      default:
        return null;
    }
  };
  
  // Handle search form submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
  };

  return (
    <div className="py-10 px-4">
      <div className="container mx-auto">
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4 gap-4">
            <div>
              <h1 className="text-3xl font-bold">Competitions</h1>
              <p className="text-gray-600">Discover creative challenges and showcase your talent</p>
            </div>
            
            <form onSubmit={handleSearch} className="w-full md:w-auto relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                type="text"
                placeholder="Search competitions..."
                className="pl-10 pr-4 py-2 rounded-full w-full md:w-64"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </form>
          </div>
          
          <div className="flex space-x-1 overflow-x-auto pb-2">
            <div className="flex bg-white rounded-full p-1 shadow-sm">
              <button 
                className={cn(
                  "tab px-4 py-2 text-sm rounded-full whitespace-nowrap",
                  selectedCategory === 'all' 
                    ? "bg-primary text-white" 
                    : "text-gray-700 hover:bg-gray-100"
                )}
                onClick={() => setSelectedCategory('all')}
              >
                <Trophy className="h-3 w-3 inline-block mr-1" />
                All Competitions
              </button>
              
              {categories?.map(category => (
                <button 
                  key={category.id}
                  className={cn(
                    "tab px-4 py-2 text-sm rounded-full whitespace-nowrap",
                    selectedCategory === category.name.toLowerCase() 
                      ? "bg-primary text-white" 
                      : "text-gray-700 hover:bg-gray-100"
                  )}
                  onClick={() => setSelectedCategory(category.name.toLowerCase())}
                >
                  {getCategoryIcon(category.name)}
                  {category.name}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        {error ? (
          <div className="bg-red-50 text-red-500 p-4 rounded-md">
            Error loading competitions. Please try again later.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {isLoading ? (
              // Skeleton loading state
              Array(6).fill(null).map((_, index) => (
                <div key={index} className="bg-white rounded-xl shadow-sm overflow-hidden">
                  <Skeleton className="h-36 w-full" />
                  <div className="p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <Skeleton className="h-6 w-20" />
                      <Skeleton className="h-4 w-24" />
                    </div>
                    <Skeleton className="h-6 w-3/4 mb-1" />
                    <Skeleton className="h-4 w-full mb-3" />
                    <div className="flex justify-between items-center">
                      <Skeleton className="h-5 w-24" />
                      <Skeleton className="h-5 w-16" />
                    </div>
                  </div>
                </div>
              ))
            ) : (
              filteredCompetitions?.length ? (
                filteredCompetitions.map(competition => (
                  <CompetitionCard key={competition.id} competition={competition} />
                ))
              ) : (
                <div className="col-span-1 md:col-span-2 lg:col-span-3 text-center py-10">
                  <p className="text-gray-500 mb-4">
                    {searchQuery ? 
                      `No competitions found matching "${searchQuery}"` : 
                      "No competitions found for this category."}
                  </p>
                  <Button onClick={() => {
                    setSelectedCategory('all');
                    setSearchQuery('');
                  }}>
                    View All Competitions
                  </Button>
                </div>
              )
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default CompetitionsPage;
