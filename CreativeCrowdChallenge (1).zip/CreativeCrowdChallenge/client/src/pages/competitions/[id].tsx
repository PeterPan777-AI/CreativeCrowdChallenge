import { useQuery } from '@tanstack/react-query';
import { Link, useLocation } from 'wouter';
import { Competition, Category, Submission, User } from '@/lib/types';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Camera, Video, Headphones, Mic, Calendar, Clock, Trophy, Users, ArrowRight } from 'lucide-react';
import { formatDistanceToNow, format, isPast, isFuture, isToday } from 'date-fns';
import SubmissionCard from '@/components/submission/submission-card';
import CategoryBadge from '@/components/ui/category-badge';
import { useToast } from '@/hooks/use-toast';

interface CompetitionPageProps {
  id: string;
  user: User | null;
}

const CompetitionPage = ({ id, user }: CompetitionPageProps) => {
  const [_, navigate] = useLocation();
  const { toast } = useToast();

  // Fetch competition
  const { data: competition, isLoading: loadingCompetition, error } = useQuery<Competition>({
    queryKey: ['/api/competitions', parseInt(id)],
    queryFn: async () => {
      const response = await fetch(`/api/competitions/${id}`);
      if (!response.ok) {
        throw new Error('Failed to fetch competition');
      }
      return response.json();
    }
  });

  // Fetch category
  const { data: category, isLoading: loadingCategory } = useQuery<Category>({
    queryKey: ['/api/categories', competition?.categoryId],
    queryFn: async () => {
      const response = await fetch(`/api/categories/${competition?.categoryId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch category');
      }
      return response.json();
    },
    enabled: !!competition,
  });

  // Fetch competition submissions
  const { data: submissions, isLoading: loadingSubmissions } = useQuery<Submission[]>({
    queryKey: ['/api/submissions', { competitionId: parseInt(id) }],
    queryFn: async () => {
      const response = await fetch(`/api/submissions?competitionId=${id}`);
      if (!response.ok) {
        throw new Error('Failed to fetch submissions');
      }
      return response.json();
    },
    enabled: !!competition,
  });

  // Fetch leaderboard
  const { data: leaderboard, isLoading: loadingLeaderboard } = useQuery({
    queryKey: ['/api/leaderboard', { competitionId: parseInt(id), limit: 5 }],
    queryFn: async () => {
      const response = await fetch(`/api/leaderboard?competitionId=${id}&limit=5`);
      if (!response.ok) {
        throw new Error('Failed to fetch leaderboard');
      }
      return response.json();
    },
    enabled: !!competition,
  });

  const isLoading = loadingCompetition || loadingCategory;

  const handleRemind = () => {
    toast({
      title: "Reminder set!",
      description: `We'll remind you about ${competition?.title} before it ends.`,
    });
  };

  const handleSubmit = () => {
    if (!user) {
      toast({
        title: "Login required",
        description: "Please log in to submit your work to this competition.",
        variant: "destructive",
      });
      navigate("/login");
      return;
    }

    navigate(`/submit?competitionId=${id}`);
  };

  const getCompetitionStatus = () => {
    if (!competition) return null;

    const now = new Date();
    const startDate = new Date(competition.startDate);
    const endDate = new Date(competition.endDate);

    if (isFuture(startDate)) {
      return {
        label: "Coming Soon",
        color: "bg-blue-100 text-blue-800",
        description: `Starts ${formatDistanceToNow(startDate, { addSuffix: true })}`
      };
    } else if (isPast(endDate)) {
      return {
        label: "Ended",
        color: "bg-gray-100 text-gray-800",
        description: `Ended ${formatDistanceToNow(endDate, { addSuffix: true })}`
      };
    } else {
      return {
        label: "Active",
        color: "bg-green-100 text-green-800",
        description: `Ends ${formatDistanceToNow(endDate, { addSuffix: true })}`
      };
    }
  };

  const getCategoryIcon = () => {
    if (!category) return null;
    
    switch (category.name.toLowerCase()) {
      case 'photography':
        return <Camera className="h-5 w-5" />;
      case 'video':
        return <Video className="h-5 w-5" />;
      case 'music':
        return <Headphones className="h-5 w-5" />;
      case 'lyrics':
        return <Mic className="h-5 w-5" />;
      default:
        return null;
    }
  };

  const getInitials = (name: string = 'User') => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };

  const status = getCompetitionStatus();

  if (error || (!isLoading && !competition)) {
    return (
      <div className="container mx-auto px-4 py-10">
        <div className="max-w-4xl mx-auto bg-red-50 text-red-500 p-8 rounded-lg">
          <h1 className="text-2xl font-bold mb-2">Competition Not Found</h1>
          <p>We couldn't find the competition you were looking for. It may have been removed or doesn't exist.</p>
          <Button asChild className="mt-4">
            <Link href="/competitions">
              <a>Browse Competitions</a>
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-10">
      {isLoading ? (
        <div className="max-w-4xl mx-auto">
          <Skeleton className="h-10 w-3/4 mb-2" />
          <Skeleton className="h-6 w-1/2 mb-6" />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            <div className="md:col-span-2">
              <Skeleton className="h-60 w-full rounded-lg mb-4" />
              <Skeleton className="h-6 w-full mb-2" />
              <Skeleton className="h-6 w-full mb-2" />
              <Skeleton className="h-6 w-2/3" />
            </div>
            
            <div>
              <Skeleton className="h-40 w-full rounded-lg mb-4" />
              <Skeleton className="h-10 w-full mb-2" />
              <Skeleton className="h-10 w-full" />
            </div>
          </div>
        </div>
      ) : (
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            {category && (
              <CategoryBadge 
                category={category.name} 
                icon={getCategoryIcon()} 
                className="mb-2"
              />
            )}
            
            <h1 className="text-3xl font-bold mb-2">{competition.title}</h1>
            
            {competition.sponsoredBy && (
              <p className="text-gray-600 mb-2">Sponsored by {competition.sponsoredBy}</p>
            )}
            
            {status && (
              <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm ${status.color}`}>
                <span className="font-medium mr-1">{status.label}:</span> {status.description}
              </div>
            )}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            <div className="md:col-span-2">
              <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                <h2 className="text-xl font-bold mb-4">About This Competition</h2>
                <p className="text-gray-700 mb-6 whitespace-pre-line">{competition.description}</p>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm text-gray-500">Start Date</p>
                      <p className="font-medium">{format(new Date(competition.startDate), 'PP')}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm text-gray-500">End Date</p>
                      <p className="font-medium">{format(new Date(competition.endDate), 'PP')}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm text-gray-500">Duration</p>
                      <p className="font-medium">
                        {formatDistanceToNow(new Date(competition.endDate), {
                          addSuffix: false,
                          includeSeconds: false
                        })}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <Trophy className="h-5 w-5 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm text-gray-500">Prize</p>
                      <p className="font-medium">${competition.prizeAmount || 'Recognition'}</p>
                    </div>
                  </div>
                </div>
                
                <div className="border-t border-gray-200 pt-6">
                  <div className="flex items-center mb-4">
                    <Users className="h-5 w-5 text-gray-400 mr-3" />
                    <h3 className="font-bold">Participants: {submissions?.length || 0}</h3>
                  </div>
                  
                  {loadingSubmissions ? (
                    <div className="flex gap-2 overflow-x-auto pb-2">
                      {Array(5).fill(null).map((_, i) => (
                        <Skeleton key={i} className="h-10 w-10 rounded-full flex-shrink-0" />
                      ))}
                    </div>
                  ) : submissions && submissions.length > 0 ? (
                    <div className="flex gap-2 overflow-x-auto pb-2">
                      {submissions.slice(0, 10).map(submission => (
                        submission.user && (
                          <Avatar key={submission.id} className="h-10 w-10 border-2 border-white">
                            {submission.user.profilePicture ? (
                              <AvatarImage src={submission.user.profilePicture} alt={submission.user.displayName} />
                            ) : (
                              <AvatarFallback>{getInitials(submission.user.displayName)}</AvatarFallback>
                            )}
                          </Avatar>
                        )
                      ))}
                      
                      {submissions.length > 10 && (
                        <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 text-xs font-medium border-2 border-white">
                          +{submissions.length - 10}
                        </div>
                      )}
                    </div>
                  ) : (
                    <p className="text-gray-500">No participants yet. Be the first to submit!</p>
                  )}
                </div>
              </div>
            </div>
            
            <div>
              <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                <div className="mb-4">
                  <h3 className="font-bold text-lg mb-2">Competition Status</h3>
                  
                  {isPast(new Date(competition.endDate)) ? (
                    <div className="bg-gray-100 p-4 rounded-md text-center mb-4">
                      <p className="text-gray-600 font-medium">This competition has ended</p>
                    </div>
                  ) : (
                    <>
                      <div className="bg-green-50 p-4 rounded-md text-center mb-4">
                        <p className="text-green-600 font-medium">Open for submissions</p>
                        <p className="text-sm text-gray-500">
                          Ends {formatDistanceToNow(new Date(competition.endDate), { addSuffix: true })}
                        </p>
                      </div>
                      
                      <Button 
                        className="w-full bg-primary mb-2" 
                        onClick={handleSubmit}
                      >
                        Submit Your Work
                      </Button>
                      
                      <Button 
                        variant="outline" 
                        className="w-full" 
                        onClick={handleRemind}
                      >
                        <Bell className="h-4 w-4 mr-2" />
                        Remind Me
                      </Button>
                    </>
                  )}
                </div>
              </div>
              
              {!loadingLeaderboard && leaderboard && leaderboard.length > 0 && (
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="font-bold text-lg mb-4">Leaderboard</h3>
                  
                  <div className="space-y-4">
                    {leaderboard.map((entry, index) => (
                      <Link key={entry.id} href={`/submissions/${entry.id}`}>
                        <a className="flex items-center p-2 rounded-lg hover:bg-gray-50 transition">
                          <div className="font-bold text-lg text-gray-400 w-6">{index + 1}</div>
                          <Avatar className="w-8 h-8 mx-3">
                            {entry.user?.profilePicture ? (
                              <AvatarImage 
                                src={entry.user.profilePicture} 
                                alt={entry.user.displayName} 
                              />
                            ) : (
                              <AvatarFallback>{getInitials(entry.user.displayName)}</AvatarFallback>
                            )}
                          </Avatar>
                          <div className="flex-grow">
                            <p className="font-medium text-sm">{entry.title}</p>
                            <p className="text-gray-500 text-xs">{entry.user.displayName}</p>
                          </div>
                          <div className="flex items-center bg-primary/10 px-2 py-1 rounded text-primary font-medium text-sm">
                            <span className="text-xs mr-1">★</span>
                            <span>{entry.averageRating.toFixed(1)}</span>
                          </div>
                        </a>
                      </Link>
                    ))}
                  </div>
                  
                  <div className="mt-4 pt-4 border-t">
                    <Link href={`/submissions?competitionId=${competition.id}`}>
                      <a className="flex items-center justify-center text-primary font-medium hover:underline">
                        View all submissions
                        <ArrowRight className="ml-1 h-4 w-4" />
                      </a>
                    </Link>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div className="mb-10">
            <Tabs defaultValue="submissions">
              <TabsList className="mb-6">
                <TabsTrigger value="submissions">Submissions</TabsTrigger>
                <TabsTrigger value="rules">Rules & Guidelines</TabsTrigger>
                <TabsTrigger value="prizes">Prizes</TabsTrigger>
              </TabsList>
              
              <TabsContent value="submissions" className="pt-2">
                {loadingSubmissions ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                    {Array(3).fill(null).map((_, i) => (
                      <Skeleton key={i} className="h-64 w-full rounded-lg" />
                    ))}
                  </div>
                ) : submissions && submissions.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                    {submissions.slice(0, 6).map(submission => (
                      <SubmissionCard key={submission.id} submission={submission} user={user} />
                    ))}
                  </div>
                ) : (
                  <div className="bg-gray-50 p-8 rounded-lg text-center">
                    <h3 className="text-lg font-bold mb-2">No submissions yet</h3>
                    <p className="text-gray-500 mb-4">Be the first to submit your work to this competition!</p>
                    <Button onClick={handleSubmit}>Submit Your Work</Button>
                  </div>
                )}
                
                {submissions && submissions.length > 6 && (
                  <div className="text-center mt-6">
                    <Link href={`/submissions?competitionId=${competition.id}`}>
                      <Button variant="outline">
                        View All Submissions
                      </Button>
                    </Link>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="rules" className="pt-2">
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="text-lg font-bold mb-4">Competition Rules</h3>
                  <ul className="list-disc list-inside space-y-2 text-gray-700">
                    <li>All submissions must be original work created by you.</li>
                    <li>Submissions must be related to the competition theme.</li>
                    <li>You may submit up to 3 entries per competition.</li>
                    <li>Submissions will be rated by the community on a scale of 0-10.</li>
                    <li>Winners will be selected based on the highest average rating.</li>
                    <li>The competition organizer reserves the right to disqualify submissions that violate the terms of service.</li>
                    <li>By submitting your work, you grant CreativeCompete the right to display your submission on the platform.</li>
                  </ul>
                </div>
              </TabsContent>
              
              <TabsContent value="prizes" className="pt-2">
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="text-lg font-bold mb-4">Prizes</h3>
                  
                  {competition.prizeAmount ? (
                    <div>
                      <div className="flex items-center mb-4">
                        <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary mr-4">
                          <Trophy className="h-6 w-6" />
                        </div>
                        <div>
                          <p className="font-bold text-gray-800">First Place</p>
                          <p className="text-primary font-bold text-xl">${competition.prizeAmount}</p>
                        </div>
                      </div>
                      
                      <p className="text-gray-600 mb-4">
                        The winner will be determined based on the highest average rating from community votes.
                        Additional prizes may be announced during the competition.
                      </p>
                      
                      <div className="bg-gray-50 p-4 rounded-md">
                        <p className="font-medium mb-1">Winner Announcement</p>
                        <p className="text-gray-600">
                          The winner will be announced 24 hours after the competition ends on {format(new Date(competition.endDate), 'PP')}.
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-4">
                      <p className="text-gray-500">No monetary prizes for this competition. Participate for recognition and exposure!</p>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      )}
    </div>
  );
};

export default CompetitionPage;
