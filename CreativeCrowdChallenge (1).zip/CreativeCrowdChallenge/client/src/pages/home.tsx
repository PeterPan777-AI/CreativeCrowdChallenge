import { useState } from "react";
import HeroSection from "@/components/home/hero-section";
import FeaturedCompetitions from "@/components/home/featured-competitions";
import PopularSubmissions from "@/components/home/popular-submissions";
import LeaderboardSection from "@/components/home/leaderboard-section";
import UpcomingCompetitions from "@/components/home/upcoming-competitions";
import CTASection from "@/components/home/cta-section";

const Home = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  return (
    <div>
      <HeroSection />
      <FeaturedCompetitions />
      <PopularSubmissions 
        selectedCategory={selectedCategory} 
        onCategoryChange={setSelectedCategory} 
      />
      <LeaderboardSection />
      <UpcomingCompetitions />
      <CTASection />
    </div>
  );
};

export default Home;
