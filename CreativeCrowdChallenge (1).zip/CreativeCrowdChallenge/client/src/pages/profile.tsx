import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Submission, User } from '@/lib/types';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import SubmissionCard from '@/components/submission/submission-card';
import { Link, useLocation } from 'wouter';
import { format } from 'date-fns';
import { Edit, Award, Image, LogOut, Star } from 'lucide-react';

interface ProfilePageProps {
  user: User | null;
}

const ProfilePage = ({ user }: ProfilePageProps) => {
  const [_, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("submissions");
  
  // Fetch user submissions
  const { data: userSubmissions, isLoading: loadingSubmissions } = useQuery<Submission[]>({
    queryKey: ['/api/submissions', { userId: user?.id }],
    queryFn: async () => {
      if (!user) return [];
      const response = await fetch(`/api/submissions?userId=${user.id}`);
      if (!response.ok) {
        throw new Error('Failed to fetch user submissions');
      }
      return response.json();
    },
    enabled: !!user,
  });
  
  // Get user's top rated submissions
  const topRatedSubmissions = userSubmissions
    ?.filter(submission => submission.averageRating > 0)
    .sort((a, b) => b.averageRating - a.averageRating)
    .slice(0, 4);
  
  const getInitials = (name: string = 'User') => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };
  
  if (!user) {
    return (
      <div className="container mx-auto px-4 py-10">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-3xl font-bold mb-4">Please Log In</h1>
          <p className="text-gray-600 mb-6">You need to be logged in to view your profile.</p>
          <Button asChild>
            <Link href="/login">
              <a>Log In</a>
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-10">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-8">
          <div className="bg-gradient-to-r from-primary to-secondary h-48 relative">
            <div className="absolute -bottom-16 left-8 flex items-end">
              <Avatar className="h-32 w-32 border-4 border-white">
                {user.profilePicture ? (
                  <AvatarImage src={user.profilePicture} alt={user.displayName} />
                ) : (
                  <AvatarFallback className="text-4xl">{getInitials(user.displayName)}</AvatarFallback>
                )}
              </Avatar>
            </div>
          </div>
          
          <div className="pt-20 pb-8 px-8">
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-end mb-4">
              <div>
                <h1 className="text-3xl font-bold mb-1">{user.displayName}</h1>
                <p className="text-gray-500">@{user.username}</p>
              </div>
              
              <div className="flex space-x-2 mt-4 sm:mt-0">
                <Button variant="outline" size="sm" className="flex items-center">
                  <Edit className="h-4 w-4 mr-1" />
                  Edit Profile
                </Button>
                <Button variant="outline" size="sm" className="flex items-center" onClick={() => navigate("/")}>
                  <LogOut className="h-4 w-4 mr-1" />
                  Log Out
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-gray-200 pt-6">
              <div className="flex items-center p-3 rounded-lg bg-gray-50">
                <Image className="h-8 w-8 text-primary mr-4" />
                <div>
                  <p className="text-2xl font-bold">{userSubmissions?.length || 0}</p>
                  <p className="text-gray-500 text-sm">Submissions</p>
                </div>
              </div>
              
              <div className="flex items-center p-3 rounded-lg bg-gray-50">
                <Star className="h-8 w-8 text-primary mr-4" />
                <div>
                  <p className="text-2xl font-bold">
                    {topRatedSubmissions && topRatedSubmissions.length > 0 
                      ? topRatedSubmissions[0].averageRating.toFixed(1) 
                      : '0.0'}
                  </p>
                  <p className="text-gray-500 text-sm">Highest Rating</p>
                </div>
              </div>
              
              <div className="flex items-center p-3 rounded-lg bg-gray-50">
                <Award className="h-8 w-8 text-primary mr-4" />
                <div>
                  <p className="text-2xl font-bold">0</p>
                  <p className="text-gray-500 text-sm">Competitions Won</p>
                </div>
              </div>
            </div>
            
            {user.bio && (
              <div className="mt-6">
                <h2 className="font-bold mb-2">About</h2>
                <p className="text-gray-700">{user.bio}</p>
              </div>
            )}
            
            <div className="mt-6 text-sm text-gray-500">
              <p>Member since {format(new Date(user.createdAt), 'MMMM yyyy')}</p>
            </div>
          </div>
        </div>
        
        <div className="mb-8">
          <Tabs defaultValue="submissions" onValueChange={setActiveTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="submissions">Submissions</TabsTrigger>
              <TabsTrigger value="topRated">Top Rated</TabsTrigger>
              <TabsTrigger value="drafts">Drafts</TabsTrigger>
            </TabsList>
            
            <TabsContent value="submissions">
              {loadingSubmissions ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                  {Array(6).fill(null).map((_, i) => (
                    <Skeleton key={i} className="h-64 w-full rounded-lg" />
                  ))}
                </div>
              ) : userSubmissions && userSubmissions.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                  {userSubmissions.map(submission => (
                    <SubmissionCard key={submission.id} submission={submission} user={user} />
                  ))}
                </div>
              ) : (
                <div className="bg-gray-50 p-8 rounded-lg text-center">
                  <h3 className="text-lg font-bold mb-2">No submissions yet</h3>
                  <p className="text-gray-500 mb-4">You haven't submitted any work yet.</p>
                  <Button asChild>
                    <Link href="/submit">
                      <a>Submit Your First Work</a>
                    </Link>
                  </Button>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="topRated">
              {loadingSubmissions ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                  {Array(3).fill(null).map((_, i) => (
                    <Skeleton key={i} className="h-64 w-full rounded-lg" />
                  ))}
                </div>
              ) : topRatedSubmissions && topRatedSubmissions.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                  {topRatedSubmissions.map(submission => (
                    <SubmissionCard key={submission.id} submission={submission} user={user} />
                  ))}
                </div>
              ) : (
                <div className="bg-gray-50 p-8 rounded-lg text-center">
                  <h3 className="text-lg font-bold mb-2">No rated submissions yet</h3>
                  <p className="text-gray-500 mb-4">Once your submissions receive ratings, they'll appear here.</p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="drafts">
              <div className="bg-gray-50 p-8 rounded-lg text-center">
                <h3 className="text-lg font-bold mb-2">No drafts available</h3>
                <p className="text-gray-500 mb-4">This feature is coming soon. You'll be able to save works in progress.</p>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
