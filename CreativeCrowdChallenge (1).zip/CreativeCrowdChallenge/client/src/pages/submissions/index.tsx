import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Submission, User, Category } from '@/lib/types';
import SubmissionCard from '@/components/submission/submission-card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Camera, Video, Headphones, Mic } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SubmissionsPageProps {
  user: User | null;
}

const SubmissionsPage = ({ user }: SubmissionsPageProps) => {
  const [location] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [limit, setLimit] = useState(12);
  
  // Parse query params
  const params = new URLSearchParams(location.split('?')[1] || '');
  const competitionId = params.get('competitionId');
  const userId = params.get('userId');
  
  // Fetch categories
  const { data: categories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
    queryFn: async () => {
      const response = await fetch('/api/categories');
      if (!response.ok) {
        throw new Error('Failed to fetch categories');
      }
      return response.json();
    }
  });
  
  // Fetch submissions
  const { data: submissions, isLoading, error } = useQuery<Submission[]>({
    queryKey: ['/api/submissions', { competitionId, userId, limit }],
    queryFn: async () => {
      let url = '/api/submissions?';
      if (competitionId) url += `competitionId=${competitionId}&`;
      if (userId) url += `userId=${userId}&`;
      url += `limit=${limit}`;
      
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error('Failed to fetch submissions');
      }
      return response.json();
    }
  });
  
  // Filter submissions by category if selected
  const filteredSubmissions = submissions?.filter(submission => {
    if (selectedCategory === 'all') return true;
    return submission.contentType === selectedCategory.toLowerCase();
  });
  
  const handleLoadMore = () => {
    setLimit(prev => prev + 12);
  };
  
  // Get category icon component
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'photo':
        return <Camera className="h-3 w-3 inline-block mr-1" />;
      case 'video':
        return <Video className="h-3 w-3 inline-block mr-1" />;
      case 'music':
        return <Headphones className="h-3 w-3 inline-block mr-1" />;
      case 'lyrics':
        return <Mic className="h-3 w-3 inline-block mr-1" />;
      default:
        return null;
    }
  };
  
  // Get page title based on query params
  const getPageTitle = () => {
    if (userId && userId === user?.id.toString()) {
      return 'My Submissions';
    } else if (userId) {
      return 'User Submissions';
    } else if (competitionId) {
      return 'Competition Submissions';
    } else {
      return 'Browse Submissions';
    }
  };

  return (
    <div className="py-10 px-4">
      <div className="container mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-4">{getPageTitle()}</h1>
          
          <div className="flex space-x-1">
            <div className="flex bg-white rounded-full p-1 shadow-sm overflow-x-auto">
              <button 
                className={cn(
                  "tab px-4 py-2 text-sm rounded-full",
                  selectedCategory === 'all' 
                    ? "bg-primary text-white" 
                    : "text-gray-700 hover:bg-gray-100"
                )}
                onClick={() => setSelectedCategory('all')}
              >
                All
              </button>
              <button 
                className={cn(
                  "tab px-4 py-2 text-sm rounded-full",
                  selectedCategory === 'photo' 
                    ? "bg-primary text-white" 
                    : "text-gray-700 hover:bg-gray-100"
                )}
                onClick={() => setSelectedCategory('photo')}
              >
                {getCategoryIcon('photo')}
                Photos
              </button>
              <button 
                className={cn(
                  "tab px-4 py-2 text-sm rounded-full",
                  selectedCategory === 'video' 
                    ? "bg-primary text-white" 
                    : "text-gray-700 hover:bg-gray-100"
                )}
                onClick={() => setSelectedCategory('video')}
              >
                {getCategoryIcon('video')}
                Videos
              </button>
              <button 
                className={cn(
                  "tab px-4 py-2 text-sm rounded-full",
                  selectedCategory === 'music' 
                    ? "bg-primary text-white" 
                    : "text-gray-700 hover:bg-gray-100"
                )}
                onClick={() => setSelectedCategory('music')}
              >
                {getCategoryIcon('music')}
                Music
              </button>
              <button 
                className={cn(
                  "tab px-4 py-2 text-sm rounded-full",
                  selectedCategory === 'lyrics' 
                    ? "bg-primary text-white" 
                    : "text-gray-700 hover:bg-gray-100"
                )}
                onClick={() => setSelectedCategory('lyrics')}
              >
                {getCategoryIcon('lyrics')}
                Lyrics
              </button>
            </div>
          </div>
        </div>
        
        {error ? (
          <div className="bg-red-50 text-red-500 p-4 rounded-md">
            Error loading submissions. Please try again later.
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {isLoading ? (
                // Skeleton loading state
                Array(12).fill(null).map((_, index) => (
                  <div key={index} className="bg-white rounded-xl shadow-sm overflow-hidden">
                    <Skeleton className="w-full aspect-square" />
                    <div className="p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <Skeleton className="h-6 w-40 mb-1" />
                          <Skeleton className="h-4 w-32" />
                        </div>
                        <Skeleton className="h-8 w-12 rounded" />
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Skeleton className="h-7 w-7 rounded-full" />
                          <Skeleton className="h-4 w-24" />
                        </div>
                        <Skeleton className="h-4 w-16" />
                      </div>
                      <div className="mt-4 border-t pt-4">
                        <Skeleton className="h-6 w-full" />
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                filteredSubmissions?.map(submission => (
                  <SubmissionCard key={submission.id} submission={submission} user={user} />
                ))
              )}
              
              {!isLoading && filteredSubmissions?.length === 0 && (
                <div className="col-span-1 sm:col-span-2 md:col-span-3 lg:col-span-4 text-center py-10">
                  <p className="text-gray-500 mb-4">No submissions found for this category.</p>
                  {user ? (
                    <Button asChild>
                      <a href="/submit" className="bg-primary text-white">Submit Your Work</a>
                    </Button>
                  ) : (
                    <Button asChild>
                      <a href="/login" className="bg-primary text-white">Login to Submit</a>
                    </Button>
                  )}
                </div>
              )}
            </div>
            
            {!isLoading && filteredSubmissions && filteredSubmissions.length > 0 && filteredSubmissions.length % 12 === 0 && (
              <div className="mt-8 text-center">
                <Button 
                  variant="outline"
                  onClick={handleLoadMore}
                  className="bg-white hover:bg-gray-50 text-primary font-medium px-6 py-3 rounded-full border border-gray-200 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 transition h-auto"
                >
                  Load More Submissions
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default SubmissionsPage;
