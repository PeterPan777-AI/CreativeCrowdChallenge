import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { Link } from 'wouter';
import { Submission, User, Competition } from '@/lib/types';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Camera, Video, Headphones, Mic, Play, Share2, Heart, MessageSquare, Calendar, Trophy } from 'lucide-react';
import { formatDistanceToNow, format } from 'date-fns';
import Rating from '@/components/ui/rating';
import CategoryBadge from '@/components/ui/category-badge';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface SubmissionPageProps {
  id: string;
  user: User | null;
}

const SubmissionPage = ({ id, user }: SubmissionPageProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isSharing, setIsSharing] = useState(false);

  // Fetch submission
  const { data: submission, isLoading, error } = useQuery<Submission>({
    queryKey: ['/api/submissions', parseInt(id)],
    queryFn: async () => {
      const response = await fetch(`/api/submissions/${id}`);
      if (!response.ok) {
        throw new Error('Failed to fetch submission');
      }
      return response.json();
    }
  });

  // Fetch submitter user data if not included
  const { data: submitterData } = useQuery<User>({
    queryKey: ['/api/users', submission?.userId],
    queryFn: async () => {
      const response = await fetch(`/api/users/${submission?.userId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch user data');
      }
      return response.json();
    },
    enabled: !!submission && !submission.user,
  });

  // Fetch competition data if not included
  const { data: competitionData } = useQuery<Competition>({
    queryKey: ['/api/competitions', submission?.competitionId],
    queryFn: async () => {
      const response = await fetch(`/api/competitions/${submission?.competitionId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch competition data');
      }
      return response.json();
    },
    enabled: !!submission && !submission.competition,
  });

  const submissionUser = submission?.user || submitterData;
  const submissionCompetition = submission?.competition || competitionData;

  const getInitials = (name: string = 'User') => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };

  const renderSubmissionContent = () => {
    if (!submission) return null;

    switch (submission.contentType) {
      case 'photo':
        return (
          <div className="relative w-full mb-6 rounded-lg overflow-hidden shadow-md">
            <img 
              src={submission.content} 
              alt={submission.title} 
              className="w-full object-contain max-h-[70vh]"
            />
          </div>
        );
      
      case 'video':
        // Assuming content could be a YouTube/Vimeo link or direct video URL
        const videoUrl = submission.content;
        return (
          <div className="relative w-full mb-6 rounded-lg overflow-hidden shadow-md aspect-video">
            {videoUrl.includes('youtube.com') || videoUrl.includes('youtu.be') ? (
              <iframe 
                src={videoUrl.replace('watch?v=', 'embed/')} 
                className="w-full h-full" 
                allowFullScreen
                title={submission.title}
              ></iframe>
            ) : (
              <video 
                src={videoUrl} 
                controls 
                className="w-full h-full"
                poster={submission.thumbnail}
              ></video>
            )}
          </div>
        );
      
      case 'music':
        // Assuming content is an audio URL
        return (
          <div className="relative w-full mb-6 rounded-lg overflow-hidden shadow-md bg-gradient-to-r from-purple-500 to-indigo-600 p-8 text-white">
            <div className="flex flex-col items-center justify-center mb-6">
              <div className="w-32 h-32 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center mb-4">
                <Headphones className="h-16 w-16 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-center">{submission.title}</h2>
              {submission.description && (
                <p className="text-white/80 mt-2 text-center">{submission.description}</p>
              )}
            </div>
            <audio 
              src={submission.content} 
              controls 
              className="w-full"
            ></audio>
          </div>
        );
      
      case 'lyrics':
        // Assuming content is the lyrics text
        return (
          <div className="relative w-full mb-6 rounded-lg overflow-hidden shadow-md bg-gradient-to-r from-pink-500 to-rose-500 p-8 text-white">
            <div className="flex flex-col items-center justify-center mb-6">
              <div className="w-24 h-24 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center mb-4">
                <Mic className="h-12 w-12 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-center">{submission.title}</h2>
            </div>
            <div className="bg-white/10 p-6 rounded-lg backdrop-blur-sm">
              <pre className="whitespace-pre-wrap font-sans text-md">
                {submission.content}
              </pre>
            </div>
          </div>
        );
      
      default:
        return <div>Unsupported content type</div>;
    }
  };

  const getContentTypeIcon = () => {
    if (!submission) return null;
    
    switch (submission.contentType) {
      case 'photo':
        return <Camera className="mr-2 h-4 w-4" />;
      case 'video':
        return <Video className="mr-2 h-4 w-4" />;
      case 'music':
        return <Headphones className="mr-2 h-4 w-4" />;
      case 'lyrics':
        return <Mic className="mr-2 h-4 w-4" />;
      default:
        return null;
    }
  };

  const handleShare = async () => {
    setIsSharing(true);
    try {
      if (navigator.share) {
        await navigator.share({
          title: submission?.title || 'Check out this submission',
          text: `Check out ${submission?.title} on CreativeCompete`,
          url: window.location.href,
        });
      } else {
        // Fallback - copy to clipboard
        await navigator.clipboard.writeText(window.location.href);
        toast({
          title: "Link copied to clipboard",
          description: "You can now paste the link to share this submission",
        });
      }
    } catch (error) {
      console.error('Error sharing:', error);
    } finally {
      setIsSharing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-10">
        <div className="max-w-4xl mx-auto">
          <Skeleton className="h-8 w-3/4 mb-2" />
          <Skeleton className="h-6 w-1/2 mb-6" />
          
          <Skeleton className="w-full aspect-video rounded-lg mb-6" />
          
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Skeleton className="h-10 w-10 rounded-full mr-3" />
              <div>
                <Skeleton className="h-5 w-32 mb-1" />
                <Skeleton className="h-4 w-24" />
              </div>
            </div>
            <Skeleton className="h-10 w-24 rounded-full" />
          </div>
          
          <Skeleton className="h-6 w-full mb-3" />
          <Skeleton className="h-6 w-3/4 mb-3" />
          <Skeleton className="h-6 w-5/6 mb-6" />
          
          <div className="border-t border-gray-200 pt-6 mb-6">
            <Skeleton className="h-6 w-32 mb-4" />
            <Skeleton className="h-20 w-full rounded-lg" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !submission) {
    return (
      <div className="container mx-auto px-4 py-10">
        <div className="max-w-4xl mx-auto bg-red-50 text-red-500 p-8 rounded-lg">
          <h1 className="text-2xl font-bold mb-2">Error Loading Submission</h1>
          <p>We couldn't load the submission you requested. It may have been removed or doesn't exist.</p>
          <Button asChild className="mt-4">
            <Link href="/submissions">
              <a>Browse Submissions</a>
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-10">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <CategoryBadge 
              category={submission.contentType === 'photo' ? 'Photography' : 
                         submission.contentType === 'video' ? 'Video' : 
                         submission.contentType === 'music' ? 'Music' : 'Lyrics'}
              icon={getContentTypeIcon()} 
            />
            
            {submissionCompetition && (
              <Link href={`/competitions/${submissionCompetition.id}`}>
                <a className="inline-flex items-center text-xs bg-primary/10 text-primary px-2.5 py-0.5 rounded-full">
                  <Trophy className="h-3 w-3 mr-1" />
                  {submissionCompetition.title}
                </a>
              </Link>
            )}
          </div>
          
          <h1 className="text-3xl font-bold mb-2">{submission.title}</h1>
          {submission.description && (
            <p className="text-gray-600 mb-1">{submission.description}</p>
          )}
          <p className="text-gray-500 text-sm flex items-center">
            <Calendar className="h-3 w-3 mr-1" />
            Posted {format(new Date(submission.createdAt), 'PPP')}
          </p>
        </div>
        
        {renderSubmissionContent()}
        
        <div className="flex flex-wrap gap-4 items-center justify-between mb-8">
          <div className="flex items-center">
            {submissionUser ? (
              <Link href={`/profile/${submissionUser.id}`}>
                <a className="flex items-center">
                  <Avatar className="h-10 w-10 mr-3">
                    {submissionUser.profilePicture ? (
                      <AvatarImage src={submissionUser.profilePicture} alt={submissionUser.displayName} />
                    ) : (
                      <AvatarFallback>{getInitials(submissionUser.displayName)}</AvatarFallback>
                    )}
                  </Avatar>
                  <div>
                    <p className="font-medium">{submissionUser.displayName}</p>
                    <p className="text-gray-500 text-xs">@{submissionUser.username}</p>
                  </div>
                </a>
              </Link>
            ) : (
              <div className="flex items-center">
                <Avatar className="h-10 w-10 mr-3">
                  <AvatarFallback>U</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">Unknown User</p>
                </div>
              </div>
            )}
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              className="flex items-center"
              onClick={handleShare}
              disabled={isSharing}
            >
              <Share2 className="h-4 w-4 mr-1" />
              Share
            </Button>
            
            <div className={cn(
              "flex items-center px-3 py-1 rounded-full font-medium text-sm",
              submission.averageRating > 0 ? "bg-primary/10 text-primary" : "bg-gray-100 text-gray-500"
            )}>
              <span className="mr-1">★</span>
              <span>{submission.averageRating ? submission.averageRating.toFixed(1) : '-'}</span>
              <span className="text-xs ml-1">({submission.totalRatings || 0})</span>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-200 pt-6 mb-8">
          <h2 className="text-xl font-bold mb-4">Rate This Submission</h2>
          <div className="bg-gray-50 p-6 rounded-lg">
            <Rating 
              submissionId={submission.id} 
              userId={user?.id}
              initialRating={0}
              readOnly={!user}
              size="lg"
            />
            
            {!user && (
              <div className="mt-4 text-center">
                <p className="text-gray-500 mb-2">You need to be logged in to rate submissions</p>
                <Link href="/login">
                  <Button variant="outline" size="sm">Login to Rate</Button>
                </Link>
              </div>
            )}
          </div>
        </div>
        
        {submissionCompetition && (
          <div className="border-t border-gray-200 pt-6 mb-8">
            <h2 className="text-xl font-bold mb-4">About This Competition</h2>
            <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
              <h3 className="text-lg font-bold mb-2">{submissionCompetition.title}</h3>
              <p className="text-gray-600 mb-4">{submissionCompetition.description}</p>
              
              <div className="flex flex-wrap gap-4 text-sm">
                <div>
                  <p className="text-gray-500">Prize</p>
                  <p className="font-medium">${submissionCompetition.prizeAmount || 0}</p>
                </div>
                
                <div>
                  <p className="text-gray-500">Ends</p>
                  <p className="font-medium">{format(new Date(submissionCompetition.endDate), 'PP')}</p>
                </div>
              </div>
              
              <div className="mt-4">
                <Link href={`/competitions/${submissionCompetition.id}`}>
                  <Button variant="outline" size="sm">View Competition</Button>
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SubmissionPage;
